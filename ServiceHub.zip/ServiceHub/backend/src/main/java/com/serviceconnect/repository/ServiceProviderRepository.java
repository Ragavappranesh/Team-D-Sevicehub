package com.serviceconnect.repository;

import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.model.ServiceProvider.ProviderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ServiceProviderRepository extends JpaRepository<ServiceProvider, String> {
    Optional<ServiceProvider> findByUserId(String userId);
    List<ServiceProvider> findByStatus(ProviderStatus status);
    List<ServiceProvider> findByCategoryId(String categoryId);
    
    @Query("SELECT p FROM ServiceProvider p WHERE " +
           "(:categoryId IS NULL OR p.category.id = :categoryId) AND " +
           "(:status IS NULL OR p.status = :status) AND " +
           "(:minRating IS NULL OR p.rating >= :minRating)")
    List<ServiceProvider> findWithFilters(
        @Param("categoryId") String categoryId,
        @Param("status") ProviderStatus status,
        @Param("minRating") Double minRating
    );
}
