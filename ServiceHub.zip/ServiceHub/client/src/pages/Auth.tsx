import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { useAuth, AppRole } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { User, Briefcase, Shield, ArrowLeft, Eye, EyeOff, MapPin, Loader2 } from 'lucide-react';
import Navbar from '@/components/layout/Navbar';

interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
}

const Auth: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { login, register, user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || 'login');
  const [selectedRole, setSelectedRole] = useState<AppRole>(
    (searchParams.get('role') as AppRole) || 'user'
  );
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [locationCoords, setLocationCoords] = useState<{ lat: number; lng: number } | null>(null);
  
  // Form states
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    category: '',
    description: '',
    hourlyRate: '',
    location: '',
    workHours: '9 AM - 6 PM',
  });

  useEffect(() => {
    if (user && !authLoading) {
      switch (user.role) {
        case 'admin': navigate('/admin'); break;
        case 'provider': navigate('/provider/dashboard'); break;
        default: navigate('/dashboard');
      }
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    // Fetch categories from Supabase
    const fetchCategories = async () => {
      const { data, error } = await supabase
        .from('service_categories')
        .select('id, name, icon');
      
      if (!error && data) {
        setCategories(data);
      }
    };
    fetchCategories();
  }, []);

  const getCurrentLocation = () => {
    setIsGettingLocation(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            setLocationCoords({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
            // Reverse geocoding using a free service
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${position.coords.latitude}&lon=${position.coords.longitude}`
            );
            const data = await response.json();
            const address = data.address;
            const locationText = [
              address.suburb || address.neighbourhood || address.village,
              address.city || address.town || address.state_district,
              address.state
            ].filter(Boolean).join(', ');
            
            setRegisterForm(prev => ({ ...prev, location: locationText || 'Location detected' }));
            toast({
              title: 'Location detected',
              description: locationText || 'Your location has been set.',
            });
          } catch (error) {
            setRegisterForm(prev => ({
              ...prev,
              location: `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`
            }));
          }
          setIsGettingLocation(false);
        },
        (error) => {
          toast({
            title: 'Location error',
            description: 'Unable to get your location. Please enter manually.',
            variant: 'destructive',
          });
          setIsGettingLocation(false);
        }
      );
    } else {
      toast({
        title: 'Not supported',
        description: 'Geolocation is not supported by your browser.',
        variant: 'destructive',
      });
      setIsGettingLocation(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const result = await login(loginForm.email, loginForm.password, selectedRole);
    
    if (result.success) {
      toast({
        title: 'Welcome back!',
        description: 'You have successfully logged in.',
      });
    } else {
      toast({
        title: 'Login failed',
        description: result.error || 'Invalid email or password.',
        variant: 'destructive',
      });
    }
    setIsLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (registerForm.password !== registerForm.confirmPassword) {
      toast({
        title: 'Password mismatch',
        description: 'Passwords do not match.',
        variant: 'destructive',
      });
      setIsLoading(false);
      return;
    }

    if (registerForm.password.length < 6) {
      toast({
        title: 'Weak password',
        description: 'Password must be at least 6 characters.',
        variant: 'destructive',
      });
      setIsLoading(false);
      return;
    }

    const result = await register({
      email: registerForm.email,
      password: registerForm.password,
      name: registerForm.name,
      phone: registerForm.phone,
      role: selectedRole,
      category: registerForm.category,
      description: registerForm.description,
      hourlyRate: parseFloat(registerForm.hourlyRate) || 0,
      location: registerForm.location,
      latitude: locationCoords?.lat,
      longitude: locationCoords?.lng,
      workHours: registerForm.workHours,
    });

    if (result.success) {
      if (selectedRole === 'provider') {
        toast({
          title: 'Registration submitted!',
          description: 'Your application is pending admin approval. You will be notified once approved.',
        });
        setActiveTab('login');
        setRegisterForm({
          name: '',
          email: '',
          phone: '',
          password: '',
          confirmPassword: '',
          category: '',
          description: '',
          hourlyRate: '',
          location: '',
          workHours: '9 AM - 6 PM',
        });
      } else {
        toast({
          title: 'Welcome!',
          description: 'Your account has been created successfully.',
        });
      }
    } else {
      toast({
        title: 'Registration failed',
        description: result.error || 'This email is already registered.',
        variant: 'destructive',
      });
    }
    setIsLoading(false);
  };

  const roles = [
    { value: 'user', label: 'Customer', icon: User, description: 'Book services' },
    { value: 'provider', label: 'Provider', icon: Briefcase, description: 'Offer services' },
    { value: 'admin', label: 'Admin', icon: Shield, description: 'Manage platform' },
  ];

  return (
    <>
      <Helmet>
        <title>Sign In - ServiceHub</title>
        <meta name="description" content="Sign in to ServiceHub to book services or manage your provider account." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8 md:py-16">
          <div className="max-w-lg mx-auto">
            <Button 
              variant="ghost" 
              className="mb-6 gap-2"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>

            <Card className="shadow-xl border-0">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-xl bg-primary flex items-center justify-center mb-4">
                  <span className="text-xl font-bold text-primary-foreground">S</span>
                </div>
                <CardTitle className="text-2xl">Welcome to ServiceHub</CardTitle>
                <CardDescription>
                  {activeTab === 'login' ? 'Sign in to your account' : 'Create a new account'}
                </CardDescription>
              </CardHeader>

              <CardContent>
                {/* Role Selector */}
                <div className="grid grid-cols-3 gap-2 mb-6">
                  {roles.map((role) => (
                    <button
                      key={role.value}
                      type="button"
                      onClick={() => setSelectedRole(role.value as AppRole)}
                      className={`p-3 rounded-xl border-2 transition-all text-center ${
                        selectedRole === role.value
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <role.icon className={`h-5 w-5 mx-auto mb-1 ${
                        selectedRole === role.value ? 'text-primary' : 'text-muted-foreground'
                      }`} />
                      <div className="text-xs font-medium">{role.label}</div>
                    </button>
                  ))}
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-2 mb-6">
                    <TabsTrigger value="login">Sign In</TabsTrigger>
                    <TabsTrigger value="register" disabled={selectedRole === 'admin'}>
                      Sign Up
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="login">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="login-email">Email</Label>
                        <Input
                          id="login-email"
                          type="email"
                          placeholder="you@example.com"
                          value={loginForm.email}
                          onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="login-password">Password</Label>
                        <div className="relative">
                          <Input
                            id="login-password"
                            type={showPassword ? 'text' : 'password'}
                            placeholder="••••••••"
                            value={loginForm.password}
                            onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                            required
                            className="pr-10"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-muted-foreground" />}
                          </Button>
                        </div>
                      </div>
                      
                      <Button type="submit" className="w-full" disabled={isLoading}>
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Signing in...
                          </>
                        ) : (
                          'Sign In'
                        )}
                      </Button>
                    </form>
                  </TabsContent>

                  <TabsContent value="register">
                    <form onSubmit={handleRegister} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="register-name">Full Name</Label>
                        <Input
                          id="register-name"
                          placeholder="John Doe"
                          value={registerForm.name}
                          onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-email">Email</Label>
                        <Input
                          id="register-email"
                          type="email"
                          placeholder="you@example.com"
                          value={registerForm.email}
                          onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-phone">Phone Number</Label>
                        <Input
                          id="register-phone"
                          type="tel"
                          placeholder="+91 98765 43210"
                          value={registerForm.phone}
                          onChange={(e) => setRegisterForm({ ...registerForm, phone: e.target.value })}
                          required
                        />
                      </div>

                      {selectedRole === 'provider' && (
                        <>
                          <div className="space-y-2">
                            <Label htmlFor="register-category">Service Category</Label>
                            <select
                              id="register-category"
                              className="flex h-11 w-full rounded-lg border-2 border-input bg-card px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                              value={registerForm.category}
                              onChange={(e) => setRegisterForm({ ...registerForm, category: e.target.value })}
                              required
                            >
                              <option value="">Select a category</option>
                              {categories.map((cat) => (
                                <option key={cat.id} value={cat.name}>
                                  {cat.name}
                                </option>
                              ))}
                            </select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="register-description">Service Description</Label>
                            <Input
                              id="register-description"
                              placeholder="Brief description of your services"
                              value={registerForm.description}
                              onChange={(e) => setRegisterForm({ ...registerForm, description: e.target.value })}
                              required
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="register-rate">Hourly Rate (₹)</Label>
                              <Input
                                id="register-rate"
                                type="number"
                                placeholder="500"
                                value={registerForm.hourlyRate}
                                onChange={(e) => setRegisterForm({ ...registerForm, hourlyRate: e.target.value })}
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="register-location">Location</Label>
                              <div className="relative">
                                <Input
                                  id="register-location"
                                  placeholder="City, Area"
                                  value={registerForm.location}
                                  onChange={(e) => setRegisterForm({ ...registerForm, location: e.target.value })}
                                  required
                                  className="pr-10"
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                                  onClick={getCurrentLocation}
                                  disabled={isGettingLocation}
                                >
                                  {isGettingLocation ? (
                                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                                  ) : (
                                    <MapPin className="h-4 w-4 text-muted-foreground" />
                                  )}
                                </Button>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="register-hours">Work Hours</Label>
                            <Input
                              id="register-hours"
                              placeholder="9 AM - 6 PM"
                              value={registerForm.workHours}
                              onChange={(e) => setRegisterForm({ ...registerForm, workHours: e.target.value })}
                            />
                          </div>
                        </>
                      )}

                      <div className="space-y-2">
                        <Label htmlFor="register-password">Password</Label>
                        <div className="relative">
                          <Input
                            id="register-password"
                            type={showPassword ? 'text' : 'password'}
                            placeholder="••••••••"
                            value={registerForm.password}
                            onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                            required
                            className="pr-10"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-muted-foreground" />}
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-confirm-password">Confirm Password</Label>
                        <div className="relative">
                          <Input
                            id="register-confirm-password"
                            type={showConfirmPassword ? 'text' : 'password'}
                            placeholder="••••••••"
                            value={registerForm.confirmPassword}
                            onChange={(e) => setRegisterForm({ ...registerForm, confirmPassword: e.target.value })}
                            required
                            className="pr-10"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          >
                            {showConfirmPassword ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-muted-foreground" />}
                          </Button>
                        </div>
                      </div>
                      
                      <Button type="submit" className="w-full" disabled={isLoading}>
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating account...
                          </>
                        ) : (
                          'Create Account'
                        )}
                      </Button>

                      {selectedRole === 'provider' && (
                        <p className="text-xs text-center text-muted-foreground">
                          Provider accounts require admin approval before you can start accepting bookings.
                        </p>
                      )}
                    </form>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
};

export default Auth;
