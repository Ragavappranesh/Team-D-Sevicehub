import React from 'react';
import { MapPin, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LocationMessageProps {
  address: string;
  lat?: number;
  lng?: number;
  className?: string;
}

const LocationMessage: React.FC<LocationMessageProps> = ({
  address,
  lat,
  lng,
  className = '',
}) => {
  const openInMaps = () => {
    if (lat && lng) {
      window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
    } else {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`,
        '_blank'
      );
    }
  };

  return (
    <div
      className={`flex items-center gap-2 p-3 bg-primary/10 rounded-lg cursor-pointer hover:bg-primary/20 transition-colors ${className}`}
      onClick={openInMaps}
    >
      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
        <MapPin className="h-5 w-5 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{address}</p>
        <p className="text-xs text-muted-foreground">Tap to view in maps</p>
      </div>
      <ExternalLink className="h-4 w-4 text-muted-foreground flex-shrink-0" />
    </div>
  );
};

export default LocationMessage;
