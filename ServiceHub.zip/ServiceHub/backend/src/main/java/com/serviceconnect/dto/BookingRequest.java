package com.serviceconnect.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class BookingRequest {
    @NotBlank
    private String providerId;
    
    @NotBlank
    private String scheduledDate;
    
    @NotBlank
    private String location;
    
    private Double latitude;
    private Double longitude;
    private String notes;
    
    @NotNull
    private Double hourlyRate;
}
