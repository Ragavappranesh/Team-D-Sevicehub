package com.serviceconnect.controller;

import com.serviceconnect.dto.BookingRequest;
import com.serviceconnect.model.Booking;
import com.serviceconnect.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {
    
    @Autowired
    private BookingService bookingService;
    
    @PostMapping
    public ResponseEntity<Booking> createBooking(@Valid @RequestBody BookingRequest request, Authentication authentication) {
        String email = authentication.getName();
        return ResponseEntity.ok(bookingService.createBooking(request, email));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.getBookingById(id));
    }
    
    @GetMapping("/user")
    public ResponseEntity<List<Booking>> getUserBookings(Authentication authentication) {
        String email = authentication.getName();
        return ResponseEntity.ok(bookingService.getUserBookings(email));
    }
    
    @GetMapping("/provider")
    public ResponseEntity<List<Booking>> getProviderBookings(Authentication authentication) {
        String email = authentication.getName();
        return ResponseEntity.ok(bookingService.getProviderBookings(email));
    }
    
    @PostMapping("/{id}/accept")
    public ResponseEntity<Booking> acceptBooking(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.acceptBooking(id));
    }
    
    @PostMapping("/{id}/reject")
    public ResponseEntity<Booking> rejectBooking(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.rejectBooking(id));
    }
    
    @PostMapping("/{id}/start")
    public ResponseEntity<Booking> startBooking(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.startBooking(id));
    }
    
    @PostMapping("/{id}/end")
    public ResponseEntity<Booking> endBooking(@PathVariable String id) {
        return ResponseEntity.ok(bookingService.endBooking(id));
    }
}
