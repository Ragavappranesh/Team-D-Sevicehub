# Java Spring Boot Backend API Requirements

This document describes the REST API endpoints your Java Spring Boot backend needs to implement to work with the ServiceHub frontend.

## Base Configuration

- **Base URL**: Configure via `VITE_API_BASE_URL` environment variable (default: `http://localhost:8080/api`)
- **Razorpay Key**: Configure via `VITE_RAZORPAY_KEY_ID` environment variable
- **Authentication**: JWT Bearer token in `Authorization` header

## Database Schema (MySQL)

```sql
-- Users table
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    avatar_url TEXT,
    role ENUM('user', 'provider', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service Categories
CREATE TABLE service_categories (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50) NOT NULL,
    image_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service Providers
CREATE TABLE service_providers (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    category_id VARCHAR(36),
    description TEXT,
    hourly_rate DECIMAL(10, 2) DEFAULT 0,
    location VARCHAR(255),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    rating DECIMAL(3, 2) DEFAULT 0,
    review_count INT DEFAULT 0,
    avatar_url TEXT,
    badges JSON,
    work_hours VARCHAR(100),
    status ENUM('pending', 'approved', 'rejected', 'suspended') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (category_id) REFERENCES service_categories(id)
);

-- Provider Portfolio
CREATE TABLE provider_portfolio (
    id VARCHAR(36) PRIMARY KEY,
    provider_id VARCHAR(36) NOT NULL,
    image_url TEXT NOT NULL,
    title VARCHAR(255),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (provider_id) REFERENCES service_providers(id)
);

-- Bookings
CREATE TABLE bookings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    provider_id VARCHAR(36) NOT NULL,
    scheduled_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    notes TEXT,
    status ENUM('requested', 'accepted', 'in_progress', 'completed', 'cancelled') DEFAULT 'requested',
    hourly_rate DECIMAL(10, 2) NOT NULL,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    total_hours DECIMAL(5, 2),
    total_amount DECIMAL(10, 2),
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (provider_id) REFERENCES service_providers(id)
);

-- Chat Messages
CREATE TABLE chat_messages (
    id VARCHAR(36) PRIMARY KEY,
    booking_id VARCHAR(36) NOT NULL,
    sender_id VARCHAR(36) NOT NULL,
    content TEXT NOT NULL,
    message_type ENUM('text', 'image', 'location') DEFAULT 'text',
    image_url TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id),
    FOREIGN KEY (sender_id) REFERENCES users(id)
);

-- Reviews
CREATE TABLE reviews (
    id VARCHAR(36) PRIMARY KEY,
    booking_id VARCHAR(36) UNIQUE NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    provider_id VARCHAR(36) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (provider_id) REFERENCES service_providers(id)
);

-- Notifications
CREATE TABLE notifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('booking', 'payment', 'review', 'approval', 'system') NOT NULL,
    reference_id VARCHAR(36),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert default admin user
INSERT INTO users (id, email, password, name, role) VALUES 
(UUID(), 'adminuser@gmail.com', '$2a$10$...hashed_password_for_admin@123...', 'Admin User', 'admin');

-- Insert default categories
INSERT INTO service_categories (id, name, icon) VALUES
(UUID(), 'Plumbing', 'Wrench'),
(UUID(), 'Electrical', 'Zap'),
(UUID(), 'Cleaning', 'Sparkles'),
(UUID(), 'Beauty & Spa', 'Scissors'),
(UUID(), 'Carpentry', 'Hammer'),
(UUID(), 'Painting', 'PaintBucket'),
(UUID(), 'AC Repair', 'Wind'),
(UUID(), 'Appliance Repair', 'Settings');
```

## API Endpoints

### Authentication

#### POST /api/auth/login
Request:
```json
{
  "email": "user@example.com",
  "password": "password123",
  "role": "user" // user, provider, or admin
}
```
Response:
```json
{
  "token": "jwt_token_here",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "user",
    "avatarUrl": "https://..."
  }
}
```

#### POST /api/auth/register
Request:
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe",
  "phone": "+919876543210",
  "role": "user",
  // For providers only:
  "category": "Plumbing",
  "description": "Expert plumber",
  "hourlyRate": 500,
  "location": "Mumbai, India",
  "latitude": 19.0760,
  "longitude": 72.8777,
  "workHours": "9 AM - 6 PM"
}
```

#### POST /api/auth/logout
(Invalidate JWT token)

#### GET /api/auth/me
Returns current user from JWT token.

### Categories

#### GET /api/categories
Returns all service categories.

### Providers

#### GET /api/providers
Query params: `category`, `location`, `rating`, `priceRange`
Returns approved providers only.

#### GET /api/providers/{id}
Returns provider details.

#### POST /api/providers/{id}/approve (Admin only)
Approves a pending provider.

#### POST /api/providers/{id}/reject (Admin only)
Rejects a provider.

### Bookings

#### POST /api/bookings
#### GET /api/bookings/{id}
#### GET /api/bookings/user
#### GET /api/bookings/provider
#### POST /api/bookings/{id}/accept
#### POST /api/bookings/{id}/reject
#### POST /api/bookings/{id}/start
#### POST /api/bookings/{id}/end

### Chat

#### GET /api/chat/{bookingId}/messages
#### POST /api/chat/{bookingId}/send

### Reviews

#### POST /api/reviews
#### GET /api/reviews/provider/{providerId}

### Payments (Razorpay Integration)

#### POST /api/payments/create-order
Request:
```json
{
  "bookingId": "uuid",
  "amount": 1500
}
```
Response:
```json
{
  "orderId": "razorpay_order_id",
  "amount": 150000, // in paise
  "currency": "INR"
}
```

#### POST /api/payments/verify
Request:
```json
{
  "razorpayOrderId": "order_xxx",
  "razorpayPaymentId": "pay_xxx",
  "razorpaySignature": "signature",
  "bookingId": "uuid"
}
```

### Notifications

#### GET /api/notifications
#### POST /api/notifications/{id}/read
#### POST /api/notifications/read-all

### File Uploads

#### POST /api/upload/avatar (multipart/form-data)
#### POST /api/upload/portfolio (multipart/form-data)
#### POST /api/upload/chat (multipart/form-data)

### Admin

#### GET /api/admin/dashboard
Returns dashboard stats with users, providers, bookings, categories.

## Environment Variables (.env)

Add to your Lovable project:
```
VITE_API_BASE_URL=http://your-java-backend-url:8080/api
VITE_RAZORPAY_KEY_ID=rzp_test_xxxxx
```

## Razorpay Setup

1. Create a Razorpay account at https://razorpay.com
2. Get your API Key ID and Secret
3. In your Java backend, use the Razorpay Java SDK to:
   - Create orders
   - Verify payment signatures
4. Add webhook endpoints for payment status updates
