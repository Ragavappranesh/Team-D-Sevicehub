package com.serviceconnect.controller;

import com.razorpay.RazorpayException;
import com.serviceconnect.dto.PaymentOrderRequest;
import com.serviceconnect.dto.PaymentVerifyRequest;
import com.serviceconnect.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    
    @Autowired
    private PaymentService paymentService;
    
    @PostMapping("/create-order")
    public ResponseEntity<Map<String, Object>> createOrder(@Valid @RequestBody PaymentOrderRequest request) {
        try {
            return ResponseEntity.ok(paymentService.createOrder(request));
        } catch (RazorpayException e) {
            throw new RuntimeException("Error creating payment order: " + e.getMessage());
        }
    }
    
    @PostMapping("/verify")
    public ResponseEntity<Map<String, String>> verifyPayment(@Valid @RequestBody PaymentVerifyRequest request) {
        try {
            return ResponseEntity.ok(paymentService.verifyPayment(request));
        } catch (RazorpayException e) {
            throw new RuntimeException("Error verifying payment: " + e.getMessage());
        }
    }
}
