import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <span className="text-lg font-bold text-primary-foreground">S</span>
              </div>
              <span className="font-display text-xl font-bold">ServiceHub</span>
            </div>
            <p className="text-sm opacity-80">
              Connecting you with trusted professionals for all your home service needs.
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-display font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><Link to="/services?category=plumbing" className="hover:opacity-100">Plumbing</Link></li>
              <li><Link to="/services?category=electrical" className="hover:opacity-100">Electrical</Link></li>
              <li><Link to="/services?category=cleaning" className="hover:opacity-100">Cleaning</Link></li>
              <li><Link to="/services?category=beauty" className="hover:opacity-100">Beauty & Spa</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-display font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><Link to="/about" className="hover:opacity-100">About Us</Link></li>
              <li><Link to="/careers" className="hover:opacity-100">Careers</Link></li>
              <li><Link to="/blog" className="hover:opacity-100">Blog</Link></li>
              <li><Link to="/contact" className="hover:opacity-100">Contact</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-display font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><Link to="/help" className="hover:opacity-100">Help Center</Link></li>
              <li><Link to="/terms" className="hover:opacity-100">Terms of Service</Link></li>
              <li><Link to="/privacy" className="hover:opacity-100">Privacy Policy</Link></li>
              <li><Link to="/auth?role=provider" className="hover:opacity-100">Become a Provider</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 mt-8 pt-8 text-center text-sm opacity-60">
          <p>© {new Date().getFullYear()} ServiceHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
