package com.serviceconnect.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PaymentVerifyRequest {
    @NotBlank
    private String razorpayOrderId;
    
    @NotBlank
    private String razorpayPaymentId;
    
    @NotBlank
    private String razorpaySignature;
    
    @NotBlank
    private String bookingId;
}
