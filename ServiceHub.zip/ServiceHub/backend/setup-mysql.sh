#!/bin/bash

# MySQL Setup Script for Service Connect Hub

echo "Setting up MySQL for Service Connect Hub..."

# Create MySQL data directory
MYSQL_DATA_DIR="$HOME/mysql_data"
mkdir -p $MYSQL_DATA_DIR

# Initialize MySQL
echo "Initializing MySQL database..."
mysqld --initialize-insecure --datadir=$MYSQL_DATA_DIR --user=$USER

# Start MySQL server in background
echo "Starting MySQL server..."
mysqld --datadir=$MYSQL_DATA_DIR --socket=/tmp/mysql.sock --pid-file=/tmp/mysql.pid --user=$USER &

# Wait for MySQL to start
sleep 5

# Create database
echo "Creating database..."
mysql -u root --socket=/tmp/mysql.sock -e "CREATE DATABASE IF NOT EXISTS service_connect_hub;"

echo "MySQL setup complete!"
echo "Database: service_connect_hub"
echo "Username: root"
echo "Password: (none)"
echo ""
echo "To connect: mysql -u root --socket=/tmp/mysql.sock service_connect_hub"
