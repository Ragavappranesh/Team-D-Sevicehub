package com.serviceconnect.repository;

import com.serviceconnect.model.Booking;
import com.serviceconnect.model.Booking.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, String> {
    List<Booking> findByUserId(String userId);
    List<Booking> findByProviderId(String providerId);
    List<Booking> findByStatus(BookingStatus status);
    List<Booking> findByUserIdOrderByCreatedAtDesc(String userId);
    List<Booking> findByProvider_User_IdOrderByCreatedAtDesc(String userId);
}
