import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';

export type AppRole = 'user' | 'provider' | 'admin';

interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: AppRole;
  phone?: string;
  avatarUrl?: string;
}

interface RegisterData {
  email: string;
  password: string;
  name: string;
  phone?: string;
  role: AppRole;
  category?: string;
  description?: string;
  hourlyRate?: number;
  location?: string;
  latitude?: number;
  longitude?: number;
  workHours?: string;
}

interface AuthContextType {
  user: AuthUser | null;
  session: Session | null;
  isLoading: boolean;
  login: (email: string, password: string, role: AppRole) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch user role and profile from database
  const fetchUserData = async (userId: string, userEmail: string): Promise<AuthUser | null> => {
    try {
      // Get user role
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .single();

      // Get user profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      const role = roleData?.role || 'user';

      // For providers, check if they're approved
      if (role === 'provider') {
        const { data: providerData } = await supabase
          .from('service_providers')
          .select('status, name')
          .eq('user_id', userId)
          .single();

        if (providerData && providerData.status !== 'approved') {
          return null; // Provider not approved yet
        }
      }

      return {
        id: userId,
        email: userEmail,
        name: profileData?.name || userEmail.split('@')[0],
        role: role as AppRole,
        phone: profileData?.phone,
        avatarUrl: profileData?.avatar_url,
      };
    } catch (error) {
      console.error('Error fetching user data:', error);
      return null;
    }
  };

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, currentSession) => {
        setSession(currentSession);
        
        if (currentSession?.user) {
          // Defer fetching user data to avoid deadlock
          setTimeout(async () => {
            const userData = await fetchUserData(
              currentSession.user.id,
              currentSession.user.email || ''
            );
            setUser(userData);
            setIsLoading(false);
          }, 0);
        } else {
          setUser(null);
          setIsLoading(false);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session: currentSession } }) => {
      setSession(currentSession);
      if (currentSession?.user) {
        fetchUserData(currentSession.user.id, currentSession.user.email || '')
          .then(userData => {
            setUser(userData);
            setIsLoading(false);
          });
      } else {
        setIsLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const login = async (email: string, password: string, role: AppRole): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        setIsLoading(false);
        return { success: false, error: error.message };
      }

      if (!data.user) {
        setIsLoading(false);
        return { success: false, error: 'Login failed' };
      }

      // Verify user has the correct role
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', data.user.id)
        .single();

      if (!roleData || roleData.role !== role) {
        await supabase.auth.signOut();
        setIsLoading(false);
        return { success: false, error: `No ${role} account found with this email` };
      }

      // For providers, check if approved
      if (role === 'provider') {
        const { data: providerData } = await supabase
          .from('service_providers')
          .select('status')
          .eq('user_id', data.user.id)
          .single();

        if (!providerData || providerData.status !== 'approved') {
          await supabase.auth.signOut();
          setIsLoading(false);
          return { success: false, error: 'Your provider account is pending approval' };
        }
      }

      const userData = await fetchUserData(data.user.id, data.user.email || '');
      setUser(userData);
      setIsLoading(false);
      return { success: true };
    } catch (error: any) {
      setIsLoading(false);
      return { success: false, error: error.message };
    }
  };

  const register = async (data: RegisterData): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            name: data.name,
          },
        },
      });

      if (authError) {
        setIsLoading(false);
        return { success: false, error: authError.message };
      }

      if (!authData.user) {
        setIsLoading(false);
        return { success: false, error: 'Registration failed' };
      }

      const userId = authData.user.id;

      // Create user role entry
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: userId,
          role: data.role,
        });

      if (roleError) {
        console.error('Error creating user role:', roleError);
      }

      // For providers, create provider profile
      if (data.role === 'provider') {
        const { data: categoryData } = await supabase
          .from('service_categories')
          .select('id')
          .eq('name', data.category)
          .single();

        const { error: providerError } = await supabase
          .from('service_providers')
          .insert({
            user_id: userId,
            name: data.name,
            email: data.email,
            phone: data.phone || '',
            category_id: categoryData?.id,
            description: data.description,
            hourly_rate: data.hourlyRate || 0,
            location: data.location,
            latitude: data.latitude,
            longitude: data.longitude,
            work_hours: data.workHours,
            status: 'pending', // Requires admin approval
          });

        if (providerError) {
          console.error('Error creating provider:', providerError);
        }

        // Sign out provider - they need approval first
        await supabase.auth.signOut();
        setIsLoading(false);
        return { success: true };
      }

      // For regular users, fetch their data
      const userData = await fetchUserData(userId, data.email);
      setUser(userData);
      setIsLoading(false);
      return { success: true };
    } catch (error: any) {
      setIsLoading(false);
      return { success: false, error: error.message };
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      isLoading,
      login,
      register,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
