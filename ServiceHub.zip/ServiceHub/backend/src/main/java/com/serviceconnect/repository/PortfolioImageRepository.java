package com.serviceconnect.repository;

import com.serviceconnect.model.PortfolioImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PortfolioImageRepository extends JpaRepository<PortfolioImage, String> {
    List<PortfolioImage> findByProviderId(String providerId);
}
