package com.serviceconnect.service;

import com.serviceconnect.model.Booking;
import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.model.User;
import com.serviceconnect.repository.BookingRepository;
import com.serviceconnect.repository.ServiceProviderRepository;
import com.serviceconnect.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdminService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ServiceProviderRepository providerRepository;
    
    @Autowired
    private BookingRepository bookingRepository;
    
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        
        long totalUsers = userRepository.count();
        long totalProviders = providerRepository.count();
        long totalBookings = bookingRepository.count();
        long pendingProviders = providerRepository.findByStatus(ServiceProvider.ProviderStatus.PENDING).size();
        
        List<Booking> recentBookings = bookingRepository.findAll().stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .limit(10)
                .toList();
        
        double totalRevenue = bookingRepository.findAll().stream()
                .filter(b -> b.getPaymentStatus() == Booking.PaymentStatus.COMPLETED)
                .mapToDouble(b -> b.getTotalAmount() != null ? b.getTotalAmount() : 0.0)
                .sum();
        
        stats.put("totalUsers", totalUsers);
        stats.put("totalProviders", totalProviders);
        stats.put("totalBookings", totalBookings);
        stats.put("totalRevenue", totalRevenue);
        stats.put("pendingProviders", pendingProviders);
        stats.put("recentBookings", recentBookings);
        
        return stats;
    }
    
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    public List<ServiceProvider> getAllProviders() {
        return providerRepository.findAll();
    }
    
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
}
