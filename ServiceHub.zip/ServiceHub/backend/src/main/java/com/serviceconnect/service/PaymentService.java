package com.serviceconnect.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import com.serviceconnect.dto.PaymentOrderRequest;
import com.serviceconnect.dto.PaymentVerifyRequest;
import com.serviceconnect.model.Booking;
import com.serviceconnect.repository.BookingRepository;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentService {
    
    @Value("${razorpay.key.id}")
    private String razorpayKeyId;
    
    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    public Map<String, Object> createOrder(PaymentOrderRequest request) throws RazorpayException {
        if (razorpayKeyId == null || razorpayKeyId.isEmpty()) {
            throw new RuntimeException("Razorpay is not configured");
        }
        
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        
        RazorpayClient client = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
        
        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", (int)(request.getAmount() * 100));
        orderRequest.put("currency", "INR");
        orderRequest.put("receipt", "booking_" + booking.getId());
        
        Order order = client.orders.create(orderRequest);
        
        Map<String, Object> response = new HashMap<>();
        response.put("orderId", order.get("id"));
        response.put("amount", request.getAmount());
        response.put("currency", "INR");
        
        return response;
    }
    
    @Transactional
    public Map<String, String> verifyPayment(PaymentVerifyRequest request) throws RazorpayException {
        if (razorpayKeyId == null || razorpayKeyId.isEmpty()) {
            throw new RuntimeException("Razorpay is not configured");
        }
        
        JSONObject options = new JSONObject();
        options.put("razorpay_order_id", request.getRazorpayOrderId());
        options.put("razorpay_payment_id", request.getRazorpayPaymentId());
        options.put("razorpay_signature", request.getRazorpaySignature());
        
        boolean isValid = Utils.verifyPaymentSignature(options, razorpayKeySecret);
        
        if (isValid) {
            Booking booking = bookingRepository.findById(request.getBookingId())
                    .orElseThrow(() -> new RuntimeException("Booking not found"));
            
            booking.setPaymentStatus(Booking.PaymentStatus.COMPLETED);
            bookingRepository.save(booking);
            
            notificationService.createNotification(
                booking.getProvider().getUser().getId(),
                "Payment Received",
                "Payment received for booking #" + booking.getId(),
                com.serviceconnect.model.Notification.NotificationType.PAYMENT,
                booking.getId()
            );
            
            Map<String, String> response = new HashMap<>();
            response.put("status", "success");
            response.put("message", "Payment verified successfully");
            return response;
        } else {
            throw new RuntimeException("Payment verification failed");
        }
    }
}
