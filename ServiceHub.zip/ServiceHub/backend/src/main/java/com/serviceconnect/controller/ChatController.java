package com.serviceconnect.controller;

import com.serviceconnect.dto.ChatMessageRequest;
import com.serviceconnect.model.ChatMessage;
import com.serviceconnect.service.ChatService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {
    
    @Autowired
    private ChatService chatService;
    
    @GetMapping("/{bookingId}/messages")
    public ResponseEntity<List<ChatMessage>> getMessages(@PathVariable String bookingId) {
        return ResponseEntity.ok(chatService.getMessages(bookingId));
    }
    
    @PostMapping("/{bookingId}/send")
    public ResponseEntity<ChatMessage> sendMessage(
            @PathVariable String bookingId,
            @Valid @RequestBody ChatMessageRequest request,
            Authentication authentication) {
        String email = authentication.getName();
        return ResponseEntity.ok(chatService.sendMessage(bookingId, request, email));
    }
}
