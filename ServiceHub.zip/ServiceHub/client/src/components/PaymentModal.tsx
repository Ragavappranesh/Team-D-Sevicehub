import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { initiatePayment, RazorpayResponse } from '@/services/razorpayService';
import { Shield, Lock, Loader2, Check, CreditCard } from 'lucide-react';
import { toast } from 'sonner';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  bookingId: string;
  onPaymentSuccess: () => void;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  amount,
  bookingId,
  onPaymentSuccess,
  userName,
  userEmail,
  userPhone,
}) => {
  const [processing, setProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const handlePayment = async () => {
    setProcessing(true);

    await initiatePayment({
      bookingId,
      amount,
      prefill: {
        name: userName,
        email: userEmail,
        contact: userPhone,
      },
      onSuccess: async (response: RazorpayResponse) => {
        try {
          // Update booking payment status in database
          const { error } = await supabase
            .from('bookings')
            .update({ 
              payment_status: 'completed',
              total_amount: amount 
            })
            .eq('id', bookingId);

          if (error) throw error;

          // Send payment confirmation message in chat
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase.from('chat_messages').insert({
              booking_id: bookingId,
              sender_id: user.id,
              content: `💳 Payment of ₹${amount.toLocaleString()} completed successfully! Payment ID: ${response.razorpay_payment_id}`,
              message_type: 'text',
            });
          }

          setPaymentSuccess(true);
          toast.success('Payment successful!');
          
          setTimeout(() => {
            setProcessing(false);
            setPaymentSuccess(false);
            onPaymentSuccess();
            onClose();
          }, 2000);
        } catch (error: any) {
          console.error('Error updating payment status:', error);
          toast.error('Payment recorded but status update failed');
          setProcessing(false);
        }
      },
      onError: (error) => {
        console.error('Payment failed:', error);
        toast.error(error.message || 'Payment failed. Please try again.');
        setProcessing(false);
      },
    });
  };

  if (paymentSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <div className="flex flex-col items-center justify-center py-10">
            <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-4">
              <Check className="h-10 w-10 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold text-green-600 mb-2">Payment Successful!</h2>
            <p className="text-muted-foreground text-center">
              ₹{amount.toLocaleString()} has been paid successfully
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <Shield className="h-4 w-4 text-primary-foreground" />
            </div>
            Secure Payment via Razorpay
          </DialogTitle>
        </DialogHeader>

        {/* Amount Display */}
        <div className="bg-muted/50 rounded-lg p-4 mb-4">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Amount to Pay</span>
            <span className="text-2xl font-bold">₹{amount.toLocaleString()}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Booking ID: {bookingId.slice(0, 8)}...</p>
        </div>

        {/* Payment Info */}
        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
            <CreditCard className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium">Multiple Payment Options</p>
              <p className="text-xs text-muted-foreground">UPI, Cards, Net Banking, Wallets</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
            <Lock className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium">Secure & Encrypted</p>
              <p className="text-xs text-muted-foreground">PCI DSS compliant payment gateway</p>
            </div>
          </div>
        </div>

        {/* Pay Button */}
        <Button 
          className="w-full" 
          size="lg"
          onClick={handlePayment}
          disabled={processing}
        >
          {processing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Opening Razorpay...
            </>
          ) : (
            <>
              <Lock className="mr-2 h-4 w-4" />
              Pay ₹{amount.toLocaleString()} with Razorpay
            </>
          )}
        </Button>

        {/* Security Badge */}
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground mt-4">
          <Shield className="h-3 w-3" />
          <span>Powered by Razorpay</span>
          <span>•</span>
          <span>Test Mode</span>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;
