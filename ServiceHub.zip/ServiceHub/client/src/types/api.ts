// API Response types for Java Spring Boot backend

export type AppRole = 'user' | 'provider' | 'admin';
export type BookingStatus = 'requested' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
export type PaymentStatus = 'pending' | 'completed' | 'failed' | 'refunded';
export type ProviderStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatarUrl?: string;
  role: AppRole;
  createdAt: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
  description?: string;
  icon: string;
  imageUrl?: string;
}

export interface ServiceProvider {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  categoryId?: string;
  category?: ServiceCategory;
  description?: string;
  hourlyRate: number;
  location?: string;
  latitude?: number;
  longitude?: number;
  rating?: number;
  reviewCount?: number;
  avatarUrl?: string;
  badges?: string[];
  workHours?: string;
  status: ProviderStatus;
  createdAt: string;
}

export interface PortfolioImage {
  id: string;
  providerId: string;
  imageUrl: string;
  title?: string;
  description?: string;
  createdAt: string;
}

export interface Booking {
  id: string;
  userId: string;
  user?: User;
  providerId: string;
  provider?: ServiceProvider;
  scheduledDate: string;
  location: string;
  latitude?: number;
  longitude?: number;
  notes?: string;
  status: BookingStatus;
  hourlyRate: number;
  startTime?: string;
  endTime?: string;
  totalHours?: number;
  totalAmount?: number;
  paymentStatus: PaymentStatus;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  bookingId: string;
  senderId: string;
  sender?: User;
  content: string;
  messageType: 'text' | 'image' | 'location';
  imageUrl?: string;
  latitude?: number;
  longitude?: number;
  createdAt: string;
}

export interface Review {
  id: string;
  bookingId: string;
  userId: string;
  user?: User;
  providerId: string;
  rating: number;
  comment?: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'booking' | 'payment' | 'review' | 'approval' | 'system';
  referenceId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface CreateOrderResponse {
  orderId: string;
  amount: number;
  currency: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalProviders: number;
  totalBookings: number;
  totalRevenue: number;
  pendingProviders: number;
  recentBookings: Booking[];
}
