import { API_ENDPOINTS } from '@/config/api';

// Token management
let authToken: string | null = localStorage.getItem('authToken');

export const setAuthToken = (token: string | null) => {
  authToken = token;
  if (token) {
    localStorage.setItem('authToken', token);
  } else {
    localStorage.removeItem('authToken');
  }
};

export const getAuthToken = () => authToken;

// Base fetch wrapper with auth header
const apiFetch = async (url: string, options: RequestInit = {}) => {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (authToken) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${authToken}`;
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Request failed' }));
    throw new Error(error.message || 'Request failed');
  }

  return response.json();
};

// Auth API
export const authApi = {
  login: async (email: string, password: string, role: string) => {
    const data = await apiFetch(API_ENDPOINTS.AUTH.LOGIN, {
      method: 'POST',
      body: JSON.stringify({ email, password, role }),
    });
    if (data.token) {
      setAuthToken(data.token);
    }
    return data;
  },

  register: async (userData: {
    email: string;
    password: string;
    name: string;
    phone?: string;
    role: string;
    category?: string;
    description?: string;
    hourlyRate?: number;
    location?: string;
    latitude?: number;
    longitude?: number;
    workHours?: string;
  }) => {
    const data = await apiFetch(API_ENDPOINTS.AUTH.REGISTER, {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    if (data.token && userData.role !== 'provider') {
      setAuthToken(data.token);
    }
    return data;
  },

  logout: async () => {
    try {
      await apiFetch(API_ENDPOINTS.AUTH.LOGOUT, { method: 'POST' });
    } finally {
      setAuthToken(null);
    }
  },

  getCurrentUser: async () => {
    return apiFetch(API_ENDPOINTS.AUTH.ME);
  },
};

// Users API
export const usersApi = {
  getAll: () => apiFetch(API_ENDPOINTS.USERS.BASE),
  getById: (id: string) => apiFetch(API_ENDPOINTS.USERS.BY_ID(id)),
  updateProfile: (data: any) => apiFetch(API_ENDPOINTS.USERS.PROFILE, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
};

// Providers API
export const providersApi = {
  getAll: (params?: { category?: string; location?: string; rating?: number; priceRange?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.append('category', params.category);
    if (params?.location) searchParams.append('location', params.location);
    if (params?.rating) searchParams.append('rating', params.rating.toString());
    if (params?.priceRange) searchParams.append('priceRange', params.priceRange);
    const query = searchParams.toString();
    return apiFetch(`${API_ENDPOINTS.PROVIDERS.BASE}${query ? `?${query}` : ''}`);
  },
  getById: (id: string) => apiFetch(API_ENDPOINTS.PROVIDERS.BY_ID(id)),
  approve: (id: string) => apiFetch(API_ENDPOINTS.PROVIDERS.APPROVE(id), { method: 'POST' }),
  reject: (id: string) => apiFetch(API_ENDPOINTS.PROVIDERS.REJECT(id), { method: 'POST' }),
  getPortfolio: (id: string) => apiFetch(API_ENDPOINTS.PROVIDERS.PORTFOLIO(id)),
  addPortfolioImage: (id: string, formData: FormData) => {
    return fetch(API_ENDPOINTS.PROVIDERS.PORTFOLIO(id), {
      method: 'POST',
      headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {},
      body: formData,
    }).then(res => res.json());
  },
};

// Categories API
export const categoriesApi = {
  getAll: () => apiFetch(API_ENDPOINTS.CATEGORIES.BASE),
  getById: (id: string) => apiFetch(API_ENDPOINTS.CATEGORIES.BY_ID(id)),
};

// Bookings API
export const bookingsApi = {
  create: (data: {
    providerId: string;
    scheduledDate: string;
    location: string;
    latitude?: number;
    longitude?: number;
    notes?: string;
    hourlyRate: number;
  }) => apiFetch(API_ENDPOINTS.BOOKINGS.BASE, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  getById: (id: string) => apiFetch(API_ENDPOINTS.BOOKINGS.BY_ID(id)),
  getUserBookings: () => apiFetch(API_ENDPOINTS.BOOKINGS.USER_BOOKINGS),
  getProviderBookings: () => apiFetch(API_ENDPOINTS.BOOKINGS.PROVIDER_BOOKINGS),
  accept: (id: string) => apiFetch(API_ENDPOINTS.BOOKINGS.ACCEPT(id), { method: 'POST' }),
  reject: (id: string) => apiFetch(API_ENDPOINTS.BOOKINGS.REJECT(id), { method: 'POST' }),
  start: (id: string) => apiFetch(API_ENDPOINTS.BOOKINGS.START(id), { method: 'POST' }),
  end: (id: string) => apiFetch(API_ENDPOINTS.BOOKINGS.END(id), { method: 'POST' }),
};

// Chat API
export const chatApi = {
  getMessages: (bookingId: string) => apiFetch(API_ENDPOINTS.CHAT.MESSAGES(bookingId)),
  sendMessage: (bookingId: string, data: {
    content: string;
    messageType: 'text' | 'image' | 'location';
    imageUrl?: string;
    latitude?: number;
    longitude?: number;
  }) => apiFetch(API_ENDPOINTS.CHAT.SEND(bookingId), {
    method: 'POST',
    body: JSON.stringify(data),
  }),
};

// Reviews API
export const reviewsApi = {
  create: (data: {
    bookingId: string;
    providerId: string;
    rating: number;
    comment?: string;
  }) => apiFetch(API_ENDPOINTS.REVIEWS.BASE, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  getByProvider: (providerId: string) => apiFetch(API_ENDPOINTS.REVIEWS.BY_PROVIDER(providerId)),
  getByBooking: (bookingId: string) => apiFetch(API_ENDPOINTS.REVIEWS.BY_BOOKING(bookingId)),
};

// Payments API
export const paymentsApi = {
  createOrder: (data: { bookingId: string; amount: number }) => 
    apiFetch(API_ENDPOINTS.PAYMENTS.CREATE_ORDER, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  verifyPayment: (data: {
    razorpayOrderId: string;
    razorpayPaymentId: string;
    razorpaySignature: string;
    bookingId: string;
  }) => apiFetch(API_ENDPOINTS.PAYMENTS.VERIFY, {
    method: 'POST',
    body: JSON.stringify(data),
  }),
};

// Notifications API
export const notificationsApi = {
  getAll: () => apiFetch(API_ENDPOINTS.NOTIFICATIONS.BASE),
  markAsRead: (id: string) => apiFetch(API_ENDPOINTS.NOTIFICATIONS.MARK_READ(id), { method: 'POST' }),
  markAllAsRead: () => apiFetch(API_ENDPOINTS.NOTIFICATIONS.MARK_ALL_READ, { method: 'POST' }),
};

// Upload API
export const uploadApi = {
  uploadAvatar: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return fetch(API_ENDPOINTS.UPLOAD.AVATAR, {
      method: 'POST',
      headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {},
      body: formData,
    }).then(res => res.json());
  },
  uploadPortfolio: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return fetch(API_ENDPOINTS.UPLOAD.PORTFOLIO, {
      method: 'POST',
      headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {},
      body: formData,
    }).then(res => res.json());
  },
  uploadChat: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return fetch(API_ENDPOINTS.UPLOAD.CHAT, {
      method: 'POST',
      headers: authToken ? { 'Authorization': `Bearer ${authToken}` } : {},
      body: formData,
    }).then(res => res.json());
  },
};

// Admin API
export const adminApi = {
  getDashboard: () => apiFetch(API_ENDPOINTS.ADMIN.DASHBOARD),
  getUsers: () => apiFetch(API_ENDPOINTS.ADMIN.USERS),
  getProviders: () => apiFetch(API_ENDPOINTS.ADMIN.PROVIDERS),
  getBookings: () => apiFetch(API_ENDPOINTS.ADMIN.BOOKINGS),
};
