import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Briefcase, ArrowRight } from 'lucide-react';

const CTASection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden rounded-3xl gradient-hero p-8 md:p-16">
          {/* Background decorations */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent/20 rounded-full blur-2xl" />
          
          <div className="relative grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 text-white mb-6">
                <Briefcase className="h-4 w-4" />
                <span className="text-sm font-medium">Join Our Network</span>
              </div>
              <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
                Are You a Service Professional?
              </h2>
              <p className="text-white/80 text-lg mb-8 max-w-md">
                Grow your business, reach more customers, and manage bookings effortlessly. 
                Join thousands of professionals already on ServiceHub.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  variant="accent" 
                  size="xl"
                  onClick={() => navigate('/auth?tab=register&role=provider')}
                  className="gap-2"
                >
                  Register as Provider
                  <ArrowRight className="h-5 w-5" />
                </Button>
                <Button 
                  variant="glass" 
                  size="xl"
                  onClick={() => navigate('/about')}
                  className="text-white border-white/30 hover:bg-white/20"
                >
                  Learn More
                </Button>
              </div>
            </div>
            
            <div className="hidden md:flex justify-center">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { value: '₹50K+', label: 'Avg Monthly Earnings' },
                  { value: '100+', label: 'Jobs per Provider' },
                  { value: '0%', label: 'Commission First Month' },
                  { value: '24/7', label: 'Support Available' },
                ].map((stat, index) => (
                  <div 
                    key={index} 
                    className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center border border-white/20"
                  >
                    <div className="font-display text-2xl font-bold text-white">{stat.value}</div>
                    <div className="text-sm text-white/70">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
