package com.serviceconnect.dto;

import com.serviceconnect.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    private String id;
    private String email;
    private String name;
    private String phone;
    private String avatarUrl;
    private String role;
    private String createdAt;
    
    public static UserDTO fromEntity(User user) {
        return new UserDTO(
            user.getId(),
            user.getEmail(),
            user.getName(),
            user.getPhone(),
            user.getAvatarUrl(),
            user.getRole().name().toLowerCase(),
            user.getCreatedAt().toString()
        );
    }
}
