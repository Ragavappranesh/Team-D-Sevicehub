package com.serviceconnect.service;

import com.serviceconnect.dto.ChatMessageRequest;
import com.serviceconnect.model.Booking;
import com.serviceconnect.model.ChatMessage;
import com.serviceconnect.model.User;
import com.serviceconnect.repository.BookingRepository;
import com.serviceconnect.repository.ChatMessageRepository;
import com.serviceconnect.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ChatService {
    
    @Autowired
    private ChatMessageRepository chatMessageRepository;
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public List<ChatMessage> getMessages(String bookingId) {
        return chatMessageRepository.findByBookingIdOrderByCreatedAtAsc(bookingId);
    }
    
    @Transactional
    public ChatMessage sendMessage(String bookingId, ChatMessageRequest request, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        
        ChatMessage message = new ChatMessage();
        message.setBooking(booking);
        message.setSender(user);
        message.setContent(request.getContent());
        message.setMessageType(ChatMessage.MessageType.valueOf(request.getMessageType().toUpperCase()));
        message.setImageUrl(request.getImageUrl());
        message.setLatitude(request.getLatitude());
        message.setLongitude(request.getLongitude());
        
        return chatMessageRepository.save(message);
    }
}
