package com.serviceconnect.service;

import com.serviceconnect.dto.BookingRequest;
import com.serviceconnect.model.Booking;
import com.serviceconnect.model.Notification;
import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.model.User;
import com.serviceconnect.repository.BookingRepository;
import com.serviceconnect.repository.ServiceProviderRepository;
import com.serviceconnect.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class BookingService {
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ServiceProviderRepository providerRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    @Transactional
    public Booking createBooking(BookingRequest request, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        ServiceProvider provider = providerRepository.findById(request.getProviderId())
                .orElseThrow(() -> new RuntimeException("Provider not found"));
        
        Booking booking = new Booking();
        booking.setUser(user);
        booking.setProvider(provider);
        booking.setScheduledDate(LocalDateTime.parse(request.getScheduledDate(), DateTimeFormatter.ISO_DATE_TIME));
        booking.setLocation(request.getLocation());
        booking.setLatitude(request.getLatitude());
        booking.setLongitude(request.getLongitude());
        booking.setNotes(request.getNotes());
        booking.setHourlyRate(request.getHourlyRate());
        booking.setStatus(Booking.BookingStatus.REQUESTED);
        booking.setPaymentStatus(Booking.PaymentStatus.PENDING);
        
        booking = bookingRepository.save(booking);
        
        notificationService.createNotification(
            provider.getUser().getId(),
            "New Booking Request",
            "You have received a new booking request from " + user.getName(),
            Notification.NotificationType.BOOKING,
            booking.getId()
        );
        
        return booking;
    }
    
    public List<Booking> getUserBookings(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return bookingRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
    }
    
    public List<Booking> getProviderBookings(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return bookingRepository.findByProvider_User_IdOrderByCreatedAtDesc(user.getId());
    }
    
    public Booking getBookingById(String id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }
    
    @Transactional
    public Booking acceptBooking(String id) {
        Booking booking = getBookingById(id);
        booking.setStatus(Booking.BookingStatus.ACCEPTED);
        booking = bookingRepository.save(booking);
        
        notificationService.createNotification(
            booking.getUser().getId(),
            "Booking Accepted",
            "Your booking has been accepted by " + booking.getProvider().getName(),
            Notification.NotificationType.BOOKING,
            booking.getId()
        );
        
        return booking;
    }
    
    @Transactional
    public Booking rejectBooking(String id) {
        Booking booking = getBookingById(id);
        booking.setStatus(Booking.BookingStatus.CANCELLED);
        booking = bookingRepository.save(booking);
        
        notificationService.createNotification(
            booking.getUser().getId(),
            "Booking Cancelled",
            "Your booking has been cancelled by " + booking.getProvider().getName(),
            Notification.NotificationType.BOOKING,
            booking.getId()
        );
        
        return booking;
    }
    
    @Transactional
    public Booking startBooking(String id) {
        Booking booking = getBookingById(id);
        booking.setStatus(Booking.BookingStatus.IN_PROGRESS);
        booking.setStartTime(LocalDateTime.now());
        booking = bookingRepository.save(booking);
        
        notificationService.createNotification(
            booking.getUser().getId(),
            "Service Started",
            "Your service has started",
            Notification.NotificationType.BOOKING,
            booking.getId()
        );
        
        return booking;
    }
    
    @Transactional
    public Booking endBooking(String id) {
        Booking booking = getBookingById(id);
        booking.setStatus(Booking.BookingStatus.COMPLETED);
        booking.setEndTime(LocalDateTime.now());
        
        if (booking.getStartTime() != null) {
            long hours = java.time.Duration.between(booking.getStartTime(), booking.getEndTime()).toHours();
            booking.setTotalHours((double) hours);
            booking.setTotalAmount(booking.getHourlyRate() * hours);
        }
        
        booking = bookingRepository.save(booking);
        
        notificationService.createNotification(
            booking.getUser().getId(),
            "Service Completed",
            "Your service has been completed",
            Notification.NotificationType.BOOKING,
            booking.getId()
        );
        
        return booking;
    }
}
