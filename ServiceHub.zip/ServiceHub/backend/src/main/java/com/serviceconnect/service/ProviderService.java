package com.serviceconnect.service;

import com.serviceconnect.model.PortfolioImage;
import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.repository.PortfolioImageRepository;
import com.serviceconnect.repository.ServiceProviderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProviderService {
    
    @Autowired
    private ServiceProviderRepository providerRepository;
    
    @Autowired
    private PortfolioImageRepository portfolioImageRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    public List<ServiceProvider> getAllProviders(String category, Double rating) {
        if (category != null || rating != null) {
            return providerRepository.findWithFilters(
                category,
                ServiceProvider.ProviderStatus.APPROVED,
                rating
            );
        }
        return providerRepository.findByStatus(ServiceProvider.ProviderStatus.APPROVED);
    }
    
    public ServiceProvider getProviderById(String id) {
        return providerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Provider not found"));
    }
    
    @Transactional
    public ServiceProvider approveProvider(String id) {
        ServiceProvider provider = getProviderById(id);
        provider.setStatus(ServiceProvider.ProviderStatus.APPROVED);
        provider = providerRepository.save(provider);
        
        notificationService.createNotification(
            provider.getUser().getId(),
            "Provider Approved",
            "Your service provider account has been approved!",
            com.serviceconnect.model.Notification.NotificationType.APPROVAL,
            provider.getId()
        );
        
        return provider;
    }
    
    @Transactional
    public ServiceProvider rejectProvider(String id) {
        ServiceProvider provider = getProviderById(id);
        provider.setStatus(ServiceProvider.ProviderStatus.REJECTED);
        provider = providerRepository.save(provider);
        
        notificationService.createNotification(
            provider.getUser().getId(),
            "Provider Rejected",
            "Your service provider application has been rejected",
            com.serviceconnect.model.Notification.NotificationType.APPROVAL,
            provider.getId()
        );
        
        return provider;
    }
    
    public List<PortfolioImage> getPortfolio(String providerId) {
        return portfolioImageRepository.findByProviderId(providerId);
    }
    
    @Transactional
    public PortfolioImage addPortfolioImage(String providerId, String imageUrl, String title, String description) {
        ServiceProvider provider = getProviderById(providerId);
        
        PortfolioImage portfolio = new PortfolioImage();
        portfolio.setProvider(provider);
        portfolio.setImageUrl(imageUrl);
        portfolio.setTitle(title);
        portfolio.setDescription(description);
        
        return portfolioImageRepository.save(portfolio);
    }
}
