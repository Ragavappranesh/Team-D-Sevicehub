package com.serviceconnect.controller;

import com.serviceconnect.model.PortfolioImage;
import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.service.FileStorageService;
import com.serviceconnect.service.ProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/providers")
public class ProviderController {
    
    @Autowired
    private ProviderService providerService;
    
    @Autowired
    private FileStorageService fileStorageService;
    
    @GetMapping
    public ResponseEntity<List<ServiceProvider>> getAllProviders(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Double rating) {
        return ResponseEntity.ok(providerService.getAllProviders(category, rating));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ServiceProvider> getProviderById(@PathVariable String id) {
        return ResponseEntity.ok(providerService.getProviderById(id));
    }
    
    @PostMapping("/{id}/approve")
    public ResponseEntity<ServiceProvider> approveProvider(@PathVariable String id) {
        return ResponseEntity.ok(providerService.approveProvider(id));
    }
    
    @PostMapping("/{id}/reject")
    public ResponseEntity<ServiceProvider> rejectProvider(@PathVariable String id) {
        return ResponseEntity.ok(providerService.rejectProvider(id));
    }
    
    @GetMapping("/{id}/portfolio")
    public ResponseEntity<List<PortfolioImage>> getPortfolio(@PathVariable String id) {
        return ResponseEntity.ok(providerService.getPortfolio(id));
    }
    
    @PostMapping("/{id}/portfolio")
    public ResponseEntity<Map<String, Object>> addPortfolioImage(
            @PathVariable String id,
            @RequestParam("file") MultipartFile file,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String description) throws IOException {
        
        String imageUrl = fileStorageService.storeFile(file, "portfolio");
        PortfolioImage portfolio = providerService.addPortfolioImage(id, imageUrl, title, description);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("portfolio", portfolio);
        
        return ResponseEntity.ok(response);
    }
}
