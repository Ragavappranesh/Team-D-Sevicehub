import React from 'react';
import { Search, Calendar, MessageSquare, CheckCircle } from 'lucide-react';

const HowItWorksSection: React.FC = () => {
  const steps = [
    {
      icon: Search,
      title: 'Search & Compare',
      description: 'Browse services, compare prices, ratings, and read reviews from real customers',
    },
    {
      icon: Calendar,
      title: 'Book Instantly',
      description: 'Choose your preferred provider and schedule at a time that works for you',
    },
    {
      icon: MessageSquare,
      title: 'Chat & Track',
      description: 'Communicate in real-time, share location, and track service progress',
    },
    {
      icon: CheckCircle,
      title: 'Pay Securely',
      description: 'Pay only after service completion with our secure Razorpay integration',
    },
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            How It Works
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get professional help in 4 simple steps
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8 relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-12 left-1/2 -translate-x-1/2 w-3/4 h-0.5 bg-border" />

          {steps.map((step, index) => (
            <div key={index} className="relative text-center">
              <div className="relative inline-flex">
                <div className="w-24 h-24 rounded-2xl gradient-hero flex items-center justify-center mb-6 shadow-glow mx-auto">
                  <step.icon className="h-10 w-10 text-primary-foreground" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-accent flex items-center justify-center font-display font-bold text-accent-foreground">
                  {index + 1}
                </div>
              </div>
              <h3 className="font-display font-semibold text-xl mb-2">
                {step.title}
              </h3>
              <p className="text-muted-foreground text-sm">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
