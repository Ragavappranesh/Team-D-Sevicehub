import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { serviceCategories } from '@/data/categories';
import { ArrowRight } from 'lucide-react';

const CategoriesSection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Popular Services
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From home repairs to personal care, find verified professionals for every need
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {serviceCategories.map((category, index) => (
            <Card
              key={category.id}
              className="group cursor-pointer hover:shadow-lg hover:border-primary/20 hover:-translate-y-1 transition-all duration-300 overflow-hidden"
              onClick={() => navigate(`/services?category=${category.id}`)}
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div className="p-6">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform">
                  {category.icon}
                </div>
                <h3 className="font-display font-semibold text-lg mb-1 group-hover:text-primary transition-colors">
                  {category.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {category.description}
                </p>
                <div className="flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Explore</span>
                  <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;
