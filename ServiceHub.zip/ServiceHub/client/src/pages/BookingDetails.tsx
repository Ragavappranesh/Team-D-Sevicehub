import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Navbar from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { 
  ArrowLeft, Clock, MapPin, Send, Star, 
  CheckCircle, CreditCard, MessageSquare,
  Loader2
} from 'lucide-react';
import LocationShareButton from '@/components/LocationShareButton';
import LocationMessage from '@/components/LocationMessage';
import ImageUpload from '@/components/ImageUpload';
import PaymentModal from '@/components/PaymentModal';

interface Booking {
  id: string;
  user_id: string;
  provider_id: string;
  status: string;
  scheduled_date: string;
  start_time: string | null;
  end_time: string | null;
  total_hours: number | null;
  hourly_rate: number;
  total_amount: number | null;
  payment_status: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  notes: string | null;
  provider?: {
    name: string;
    category?: {
      name: string;
    };
  };
}

interface ChatMessage {
  id: string;
  booking_id: string;
  sender_id: string;
  content: string;
  message_type: string;
  image_url: string | null;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
}

const BookingDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [booking, setBooking] = useState<Booking | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch booking details
  useEffect(() => {
    const fetchBooking = async () => {
      if (!id || !user) return;

      try {
        const { data, error } = await supabase
          .from('bookings')
          .select(`
            *,
            provider:service_providers(name, category:service_categories(name))
          `)
          .eq('id', id)
          .maybeSingle();

        if (error) throw error;
        setBooking(data as Booking);
      } catch (error: any) {
        console.error('Error fetching booking:', error);
        toast.error('Failed to load booking details');
      } finally {
        setLoading(false);
      }
    };

    fetchBooking();
  }, [id, user]);

  // Fetch and subscribe to messages
  useEffect(() => {
    if (!id) return;

    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('booking_id', id)
        .order('created_at', { ascending: true });

      if (!error && data) {
        setMessages(data);
      }
    };

    fetchMessages();

    // Subscribe to realtime updates
    const channel = supabase
      .channel(`chat-${id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `booking_id=eq.${id}`
        },
        (payload) => {
          setMessages(prev => [...prev, payload.new as ChatMessage]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!user) {
    navigate('/auth');
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto" />
          <p className="mt-4 text-muted-foreground">Loading booking details...</p>
        </div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Booking not found</h1>
          <Button onClick={() => navigate('/dashboard')}>Go to Dashboard</Button>
        </div>
      </div>
    );
  }

  const isChatEnabled = ['accepted', 'in_progress', 'completed'].includes(booking.status);
  const isPaymentPending = booking.status === 'completed' && booking.payment_status === 'pending';

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !isChatEnabled || sending) return;

    setSending(true);
    try {
      const { error } = await supabase.from('chat_messages').insert({
        booking_id: booking.id,
        sender_id: user.id,
        content: message.trim(),
        message_type: 'text',
      });

      if (error) throw error;
      setMessage('');
    } catch (error: any) {
      toast.error('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleShareLocation = async (location: { lat: number; lng: number; address: string }) => {
    try {
      const { error } = await supabase.from('chat_messages').insert({
        booking_id: booking.id,
        sender_id: user.id,
        content: location.address,
        message_type: 'location',
        latitude: location.lat,
        longitude: location.lng,
      });

      if (error) throw error;
      toast.success('Location shared');
    } catch (error: any) {
      toast.error('Failed to share location');
    }
  };

  const handleImageUpload = async (url: string) => {
    try {
      const { error } = await supabase.from('chat_messages').insert({
        booking_id: booking.id,
        sender_id: user.id,
        content: 'Shared an image',
        message_type: 'image',
        image_url: url,
      });

      if (error) throw error;
      toast.success('Image shared');
    } catch (error: any) {
      toast.error('Failed to share image');
    }
  };

  const handlePaymentSuccess = async () => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ payment_status: 'completed' })
        .eq('id', booking.id);

      if (error) throw error;

      await supabase.from('chat_messages').insert({
        booking_id: booking.id,
        sender_id: user.id,
        content: `Payment of ₹${booking.total_amount} completed successfully!`,
        message_type: 'payment',
      });

      setBooking(prev => prev ? { ...prev, payment_status: 'completed' } : null);
      setShowPaymentModal(false);
      setShowReviewForm(true);
      toast.success('Payment successful!');
    } catch (error: any) {
      toast.error('Failed to update payment status');
    }
  };

  const handleSubmitReview = async () => {
    try {
      const { error } = await supabase.from('reviews').insert({
        booking_id: booking.id,
        user_id: user.id,
        provider_id: booking.provider_id,
        rating,
        comment: reviewText,
      });

      if (error) throw error;

      toast.success('Review submitted successfully!');
      setShowReviewForm(false);
      navigate('/dashboard');
    } catch (error: any) {
      toast.error('Failed to submit review');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'requested': return 'secondary';
      case 'accepted': return 'default';
      case 'in_progress': return 'default';
      case 'completed': return 'default';
      case 'cancelled': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusLabel = (status: string) => {
    return status.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  return (
    <>
      <Helmet>
        <title>Booking Details - ServiceHub</title>
        <meta name="description" content="View booking details and chat with your service provider." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="ghost" 
            className="mb-6 gap-2"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Booking Info */}
            <Card className="md:col-span-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Booking Details</CardTitle>
                  <Badge variant={getStatusColor(booking.status)}>
                    {getStatusLabel(booking.status)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Service</p>
                  <p className="font-semibold">{booking.provider?.category?.name || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Provider</p>
                  <p className="font-semibold">{booking.provider?.name || 'N/A'}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    {new Date(booking.scheduled_date).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{booking.location}</span>
                </div>

                {/* Pricing */}
                <div className="border-t pt-4 mt-4">
                  <p className="text-sm text-muted-foreground mb-2">Pricing</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Rate</span>
                      <span>₹{booking.hourly_rate}/hr</span>
                    </div>
                    {booking.total_hours && (
                      <>
                        <div className="flex justify-between">
                          <span>Duration</span>
                          <span>{booking.total_hours.toFixed(2)} hours</span>
                        </div>
                        <div className="flex justify-between font-semibold text-base border-t pt-2">
                          <span>Total</span>
                          <span>₹{booking.total_amount}</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Payment Button */}
                {isPaymentPending && user.role === 'user' && (
                  <Button 
                    className="w-full gap-2"
                    onClick={() => setShowPaymentModal(true)}
                  >
                    <CreditCard className="h-4 w-4" />
                    Pay ₹{booking.total_amount}
                  </Button>
                )}

                {/* Payment Completed */}
                {booking.payment_status === 'completed' && (
                  <div className="flex items-center gap-2 text-green-600 bg-green-100 dark:bg-green-900/20 p-3 rounded-lg">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-medium">Payment Complete</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Chat Section */}
            <Card className="md:col-span-2 flex flex-col h-[600px]">
              <CardHeader className="border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Chat
                  </CardTitle>
                  {isChatEnabled && (
                    <div className="flex gap-2">
                      <ImageUpload
                        bucket="chat-images"
                        userId={user.id}
                        onUpload={handleImageUpload}
                        variant="chat"
                      />
                      <LocationShareButton onShare={handleShareLocation} />
                    </div>
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                {!isChatEnabled ? (
                  <div className="flex items-center justify-center h-full text-center">
                    <div>
                      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                        <MessageSquare className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <p className="text-muted-foreground">
                        Chat will be enabled once the provider accepts your booking.
                      </p>
                    </div>
                  </div>
                ) : (
                  <>
                    {messages.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>No messages yet. Start the conversation!</p>
                      </div>
                    ) : (
                      messages.map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.sender_id === user.id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                              msg.message_type === 'payment'
                                ? 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-800'
                                : msg.sender_id === user.id
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-secondary'
                            }`}
                          >
                            {msg.message_type === 'location' && msg.latitude && msg.longitude ? (
                              <LocationMessage
                                lat={msg.latitude}
                                lng={msg.longitude}
                                address={msg.content}
                              />
                            ) : msg.message_type === 'image' && msg.image_url ? (
                              <img 
                                src={msg.image_url} 
                                alt="Shared image" 
                                className="max-w-full rounded-lg cursor-pointer"
                                onClick={() => window.open(msg.image_url!, '_blank')}
                              />
                            ) : msg.message_type === 'payment' ? (
                              <div className="flex items-center gap-2">
                                <CheckCircle className="h-4 w-4" />
                                {msg.content}
                              </div>
                            ) : (
                              <p>{msg.content}</p>
                            )}
                            <p className={`text-xs mt-1 ${
                              msg.sender_id === user.id ? 'text-primary-foreground/70' : 'text-muted-foreground'
                            }`}>
                              {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </>
                )}
              </CardContent>

              {isChatEnabled && booking.payment_status !== 'completed' && (
                <div className="p-4 border-t">
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <Input
                      placeholder="Type a message..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="flex-1"
                      disabled={sending}
                    />
                    <Button type="submit" size="icon" disabled={sending}>
                      {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    </Button>
                  </form>
                </div>
              )}
            </Card>
          </div>

          {/* Payment Modal */}
          {showPaymentModal && booking.total_amount && (
            <PaymentModal
              isOpen={showPaymentModal}
              onClose={() => setShowPaymentModal(false)}
              amount={booking.total_amount}
              bookingId={booking.id}
              onPaymentSuccess={handlePaymentSuccess}
            />
          )}

          {/* Review Modal */}
          {showReviewForm && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
              <Card className="w-full max-w-md animate-in fade-in zoom-in">
                <CardHeader>
                  <CardTitle>Rate Your Experience</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Rating</p>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`h-8 w-8 ${
                              star <= rating ? 'text-yellow-500 fill-yellow-500' : 'text-muted-foreground'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Your Review</p>
                    <Textarea
                      placeholder="Share your experience..."
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      rows={4}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setShowReviewForm(false);
                        navigate('/dashboard');
                      }}
                    >
                      Skip
                    </Button>
                    <Button
                      className="flex-1"
                      onClick={handleSubmitReview}
                    >
                      Submit Review
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default BookingDetails;
