import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Booking, BookingStatus, PaymentStatus, ChatMessage, Review } from '@/types';

interface BookingContextType {
  bookings: Booking[];
  messages: ChatMessage[];
  reviews: Review[];
  createBooking: (booking: Omit<Booking, 'id' | 'createdAt'>) => Booking;
  updateBookingStatus: (bookingId: string, status: BookingStatus) => void;
  startService: (bookingId: string) => void;
  endService: (bookingId: string) => void;
  completePayment: (bookingId: string) => void;
  sendMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  addReview: (review: Omit<Review, 'id' | 'createdAt'>) => void;
  getBookingMessages: (bookingId: string) => ChatMessage[];
  getUserBookings: (userId: string) => Booking[];
  getProviderBookings: (providerId: string) => Booking[];
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const BookingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    const savedBookings = localStorage.getItem('serviceBookings');
    const savedMessages = localStorage.getItem('serviceMessages');
    const savedReviews = localStorage.getItem('serviceReviews');
    
    if (savedBookings) setBookings(JSON.parse(savedBookings));
    if (savedMessages) setMessages(JSON.parse(savedMessages));
    if (savedReviews) setReviews(JSON.parse(savedReviews));
  }, []);

  useEffect(() => {
    localStorage.setItem('serviceBookings', JSON.stringify(bookings));
    localStorage.setItem('serviceMessages', JSON.stringify(messages));
    localStorage.setItem('serviceReviews', JSON.stringify(reviews));
  }, [bookings, messages, reviews]);

  const createBooking = (bookingData: Omit<Booking, 'id' | 'createdAt'>): Booking => {
    const newBooking: Booking = {
      ...bookingData,
      id: `booking-${Date.now()}`,
      createdAt: new Date(),
    };
    setBookings(prev => [...prev, newBooking]);
    return newBooking;
  };

  const updateBookingStatus = (bookingId: string, status: BookingStatus) => {
    setBookings(prev =>
      prev.map(b => b.id === bookingId ? { ...b, status } : b)
    );
  };

  const startService = (bookingId: string) => {
    setBookings(prev =>
      prev.map(b => b.id === bookingId ? { 
        ...b, 
        status: 'in_progress' as BookingStatus,
        startTime: new Date() 
      } : b)
    );
  };

  const endService = (bookingId: string) => {
    setBookings(prev =>
      prev.map(b => {
        if (b.id === bookingId && b.startTime) {
          const endTime = new Date();
          const startTime = new Date(b.startTime);
          const totalHours = Math.max(1, Math.ceil((endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60)));
          const totalAmount = totalHours * b.hourlyRate;
          
          return { 
            ...b, 
            status: 'completed' as BookingStatus,
            endTime,
            totalHours,
            totalAmount,
          };
        }
        return b;
      })
    );
  };

  const completePayment = (bookingId: string) => {
    setBookings(prev =>
      prev.map(b => b.id === bookingId ? { 
        ...b, 
        paymentStatus: 'completed' as PaymentStatus 
      } : b)
    );
    
    // Add payment confirmation message
    const booking = bookings.find(b => b.id === bookingId);
    if (booking) {
      const paymentMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        bookingId,
        senderId: 'system',
        senderRole: 'admin',
        content: `Payment of ₹${booking.totalAmount} received successfully! Thank you for using our service.`,
        type: 'payment',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, paymentMessage]);
    }
  };

  const sendMessage = (messageData: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage: ChatMessage = {
      ...messageData,
      id: `msg-${Date.now()}`,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const addReview = (reviewData: Omit<Review, 'id' | 'createdAt'>) => {
    const newReview: Review = {
      ...reviewData,
      id: `review-${Date.now()}`,
      createdAt: new Date(),
    };
    setReviews(prev => [...prev, newReview]);
  };

  const getBookingMessages = (bookingId: string) => {
    return messages.filter(m => m.bookingId === bookingId);
  };

  const getUserBookings = (userId: string) => {
    return bookings.filter(b => b.userId === userId);
  };

  const getProviderBookings = (providerId: string) => {
    return bookings.filter(b => b.providerId === providerId);
  };

  return (
    <BookingContext.Provider value={{
      bookings,
      messages,
      reviews,
      createBooking,
      updateBookingStatus,
      startService,
      endService,
      completePayment,
      sendMessage,
      addReview,
      getBookingMessages,
      getUserBookings,
      getProviderBookings,
    }}>
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (context === undefined) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};
