package com.serviceconnect.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ChatMessageRequest {
    @NotBlank
    private String content;
    
    @NotBlank
    private String messageType;
    
    private String imageUrl;
    private Double latitude;
    private Double longitude;
}
