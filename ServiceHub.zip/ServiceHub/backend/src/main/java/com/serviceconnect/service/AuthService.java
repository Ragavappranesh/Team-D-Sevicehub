package com.serviceconnect.service;

import com.serviceconnect.dto.*;
import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.model.User;
import com.serviceconnect.repository.ServiceProviderRepository;
import com.serviceconnect.repository.UserRepository;
import com.serviceconnect.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ServiceProviderRepository providerRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    public AuthResponse login(AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );
        
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        
        return new AuthResponse(token, UserDTO.fromEntity(user));
    }
    
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setName(request.getName());
        user.setPhone(request.getPhone());
        
        User.AppRole role = User.AppRole.valueOf(request.getRole().toUpperCase());
        user.setRole(role);
        
        user = userRepository.save(user);
        
        if (role == User.AppRole.PROVIDER) {
            ServiceProvider provider = new ServiceProvider();
            provider.setUser(user);
            provider.setName(request.getName());
            provider.setEmail(request.getEmail());
            provider.setPhone(request.getPhone() != null ? request.getPhone() : "");
            provider.setDescription(request.getDescription());
            provider.setHourlyRate(request.getHourlyRate() != null ? request.getHourlyRate() : 0.0);
            provider.setLocation(request.getLocation());
            provider.setLatitude(request.getLatitude());
            provider.setLongitude(request.getLongitude());
            provider.setWorkHours(request.getWorkHours());
            provider.setStatus(ServiceProvider.ProviderStatus.PENDING);
            
            providerRepository.save(provider);
            
            return new AuthResponse(null, UserDTO.fromEntity(user));
        }
        
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        return new AuthResponse(token, UserDTO.fromEntity(user));
    }
    
    public UserDTO getCurrentUser(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return UserDTO.fromEntity(user);
    }
}
