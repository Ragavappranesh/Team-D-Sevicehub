package com.serviceconnect.controller;

import com.serviceconnect.dto.ReviewRequest;
import com.serviceconnect.model.Review;
import com.serviceconnect.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewController {
    
    @Autowired
    private ReviewService reviewService;
    
    @PostMapping
    public ResponseEntity<Review> createReview(@Valid @RequestBody ReviewRequest request, Authentication authentication) {
        String email = authentication.getName();
        return ResponseEntity.ok(reviewService.createReview(request, email));
    }
    
    @GetMapping("/provider/{providerId}")
    public ResponseEntity<List<Review>> getProviderReviews(@PathVariable String providerId) {
        return ResponseEntity.ok(reviewService.getProviderReviews(providerId));
    }
    
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Review> getBookingReview(@PathVariable String bookingId) {
        Review review = reviewService.getBookingReview(bookingId);
        if (review == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(review);
    }
}
