import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Navbar from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import LocationPicker from '@/components/LocationPicker';
import { format } from 'date-fns';
import { CalendarIcon, MapPin, IndianRupee, Star, ArrowLeft, Clock, Loader2 } from 'lucide-react';

interface Provider {
  id: string;
  name: string;
  description?: string;
  hourly_rate: number;
  rating: number;
  review_count: number;
  location?: string;
  work_hours?: string;
  category?: { name: string };
}

const BookingNew: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const providerId = searchParams.get('provider');
  
  const [provider, setProvider] = useState<Provider | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [locationData, setLocationData] = useState({ address: '', lat: 0, lng: 0 });
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (providerId) {
      fetchProvider();
    }
  }, [user, providerId, navigate]);

  const fetchProvider = async () => {
    const { data } = await supabase
      .from('service_providers')
      .select('*, category:service_categories(name)')
      .eq('id', providerId)
      .eq('status', 'approved')
      .maybeSingle();

    setProvider(data);
    setIsLoading(false);
  };

  if (!user) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Provider not found</h1>
          <Button onClick={() => navigate('/services')}>Browse Services</Button>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!date) {
      toast({
        title: 'Select a date',
        description: 'Please select a preferred date for the service.',
        variant: 'destructive',
      });
      return;
    }

    if (!locationData.address.trim()) {
      toast({
        title: 'Enter location',
        description: 'Please enter your service location.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    const { data: booking, error } = await supabase
      .from('bookings')
      .insert({
        user_id: user.id,
        provider_id: provider.id,
        status: 'requested',
        scheduled_date: date.toISOString(),
        hourly_rate: provider.hourly_rate,
        payment_status: 'pending',
        location: locationData.address,
        latitude: locationData.lat || null,
        longitude: locationData.lng || null,
        notes: notes.trim() || null,
      })
      .select()
      .single();

    if (error) {
      toast({
        title: 'Booking failed',
        description: error.message,
        variant: 'destructive',
      });
      setIsSubmitting(false);
      return;
    }

    toast({
      title: 'Booking Requested!',
      description: 'Your booking request has been sent to the provider.',
    });

    navigate(`/booking/${booking.id}`);
  };

  return (
    <>
      <Helmet>
        <title>Book Service - ServiceHub</title>
        <meta name="description" content="Book a service with a verified professional on ServiceHub." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="ghost" 
            className="mb-6 gap-2"
            onClick={() => navigate('/services')}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Services
          </Button>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="md:col-span-1 h-fit">
              <CardHeader>
                <CardTitle className="text-lg">Provider Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-xl gradient-hero flex items-center justify-center text-2xl text-primary-foreground font-bold">
                    {provider.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{provider.name}</h3>
                    <p className="text-sm text-muted-foreground">{provider.category?.name || 'Service'}</p>
                  </div>
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-accent fill-accent" />
                    <span>{Number(provider.rating).toFixed(1)} ({provider.review_count} reviews)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <IndianRupee className="h-4 w-4 text-muted-foreground" />
                    <span className="font-semibold">₹{provider.hourly_rate}</span>
                    <span className="text-muted-foreground">per hour</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{provider.location || 'Location not set'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{provider.work_hours || '9 AM - 6 PM'}</span>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mt-4 pt-4 border-t">
                  {provider.description || 'Professional service provider'}
                </p>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Book Service</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label>Preferred Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, 'PPP') : 'Select a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>Service Location</Label>
                    <LocationPicker
                      onLocationSelect={setLocationData}
                      currentLocation={locationData}
                      showViewButton
                    />
                    <p className="text-xs text-muted-foreground">
                      Enter your address or click the GPS icon to use your current location
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      placeholder="Describe your requirements or any special instructions..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={4}
                    />
                  </div>

                  <div className="bg-secondary/50 rounded-xl p-4">
                    <h4 className="font-semibold mb-3">Pricing</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Hourly Rate</span>
                        <span>₹{provider.hourly_rate}/hr</span>
                      </div>
                      <div className="flex justify-between text-muted-foreground">
                        <span>Minimum Duration</span>
                        <span>1 hour</span>
                      </div>
                      <div className="border-t pt-2 mt-2 flex justify-between font-semibold">
                        <span>Estimated Minimum</span>
                        <span>₹{provider.hourly_rate}</span>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-3">
                      * Final amount will be calculated based on actual service duration
                    </p>
                  </div>

                  <Button 
                    type="submit" 
                    variant="hero" 
                    size="lg" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      'Confirm Booking Request'
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookingNew;
