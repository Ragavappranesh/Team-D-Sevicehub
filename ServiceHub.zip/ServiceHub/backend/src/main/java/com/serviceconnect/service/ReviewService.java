package com.serviceconnect.service;

import com.serviceconnect.dto.ReviewRequest;
import com.serviceconnect.model.Booking;
import com.serviceconnect.model.Review;
import com.serviceconnect.model.ServiceProvider;
import com.serviceconnect.model.User;
import com.serviceconnect.repository.BookingRepository;
import com.serviceconnect.repository.ReviewRepository;
import com.serviceconnect.repository.ServiceProviderRepository;
import com.serviceconnect.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ReviewService {
    
    @Autowired
    private ReviewRepository reviewRepository;
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ServiceProviderRepository providerRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    @Transactional
    public Review createReview(ReviewRequest request, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        if (reviewRepository.existsByBookingId(request.getBookingId())) {
            throw new RuntimeException("Review already exists for this booking");
        }
        
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        
        ServiceProvider provider = providerRepository.findById(request.getProviderId())
                .orElseThrow(() -> new RuntimeException("Provider not found"));
        
        Review review = new Review();
        review.setBooking(booking);
        review.setUser(user);
        review.setProvider(provider);
        review.setRating(request.getRating());
        review.setComment(request.getComment());
        
        review = reviewRepository.save(review);
        
        updateProviderRating(provider.getId());
        
        notificationService.createNotification(
            provider.getUser().getId(),
            "New Review",
            "You received a new " + request.getRating() + "-star review",
            com.serviceconnect.model.Notification.NotificationType.REVIEW,
            review.getId()
        );
        
        return review;
    }
    
    private void updateProviderRating(String providerId) {
        List<Review> reviews = reviewRepository.findByProviderIdOrderByCreatedAtDesc(providerId);
        
        if (!reviews.isEmpty()) {
            double avgRating = reviews.stream()
                    .mapToInt(Review::getRating)
                    .average()
                    .orElse(0.0);
            
            ServiceProvider provider = providerRepository.findById(providerId)
                    .orElseThrow(() -> new RuntimeException("Provider not found"));
            
            provider.setRating(Math.round(avgRating * 10.0) / 10.0);
            provider.setReviewCount(reviews.size());
            providerRepository.save(provider);
        }
    }
    
    public List<Review> getProviderReviews(String providerId) {
        return reviewRepository.findByProviderIdOrderByCreatedAtDesc(providerId);
    }
    
    public Review getBookingReview(String bookingId) {
        return reviewRepository.findByBookingId(bookingId).orElse(null);
    }
}
