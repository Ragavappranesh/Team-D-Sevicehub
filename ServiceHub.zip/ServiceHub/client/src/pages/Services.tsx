import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Search, MapPin, Star, Filter, X, Clock, IndianRupee, CheckCircle, Loader2 } from 'lucide-react';

interface ServiceProvider {
  id: string;
  name: string;
  description: string | null;
  hourlyRate: number;
  rating: number | null;
  reviewCount: number | null;
  location: string | null;
  categoryId: string | null;
  badges: string[] | null;
  category?: { name: string } | null;
}

interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
}

const Services: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [providers, setProviders] = useState<ServiceProvider[]>([]);
  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [location, setLocation] = useState(searchParams.get('location') || '');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [minRating, setMinRating] = useState<number>(0);
  const [priceRange, setPriceRange] = useState<number[]>([0, 2000]);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch providers with category info
      const { data: providersData, error: providersError } = await supabase
        .from('service_providers')
        .select(`
          id,
          name,
          description,
          hourly_rate,
          rating,
          review_count,
          location,
          category_id,
          badges,
          service_categories(name)
        `)
        .eq('status', 'approved');

      if (providersError) throw providersError;

      // Fetch categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('service_categories')
        .select('id, name, icon');

      if (categoriesError) throw categoriesError;

      // Transform providers data
      const transformedProviders: ServiceProvider[] = (providersData || []).map((p: any) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        hourlyRate: p.hourly_rate,
        rating: p.rating,
        reviewCount: p.review_count,
        location: p.location,
        categoryId: p.category_id,
        badges: p.badges,
        category: p.service_categories,
      }));

      setProviders(transformedProviders);
      setCategories(categoriesData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredProviders = useMemo(() => {
    return providers.filter(provider => {
      const matchesSearch = !searchQuery || 
        provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (provider.description?.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesLocation = !location || 
        (provider.location?.toLowerCase().includes(location.toLowerCase()));
      
      const matchesCategory = !selectedCategory || provider.categoryId === selectedCategory;
      
      const matchesRating = (provider.rating || 0) >= minRating;
      
      const matchesPrice = provider.hourlyRate >= priceRange[0] && provider.hourlyRate <= priceRange[1];
      
      return matchesSearch && matchesLocation && matchesCategory && matchesRating && matchesPrice;
    });
  }, [providers, searchQuery, location, selectedCategory, minRating, priceRange]);

  const handleBookNow = (providerId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    navigate(`/booking/new?provider=${providerId}`);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setLocation('');
    setSelectedCategory('');
    setMinRating(0);
    setPriceRange([0, 2000]);
    setSearchParams({});
  };

  return (
    <>
      <Helmet>
        <title>Browse Services - ServiceHub</title>
        <meta name="description" content="Find verified professionals for plumbing, electrical, cleaning, beauty services and more near you." />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        
        <main className="flex-1">
          <section className="bg-secondary/50 border-b">
            <div className="container mx-auto px-4 py-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search services..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex-1 relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button
                  variant="outline"
                  className="gap-2"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="h-4 w-4" />
                  Filters
                </Button>
              </div>

              <div className="flex flex-wrap gap-2 mt-4">
                <Button
                  variant={!selectedCategory ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory('')}
                >
                  All
                </Button>
                {categories.map((cat) => (
                  <Button
                    key={cat.id}
                    variant={selectedCategory === cat.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(cat.id)}
                  >
                    {cat.name}
                  </Button>
                ))}
              </div>

              {showFilters && (
                <div className="mt-4 p-4 bg-card rounded-xl border animate-slide-up">
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Minimum Rating</label>
                      <div className="flex items-center gap-2">
                        {[0, 3, 3.5, 4, 4.5].map((rating) => (
                          <Button
                            key={rating}
                            variant={minRating === rating ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setMinRating(rating)}
                          >
                            {rating === 0 ? 'Any' : `${rating}+`}
                            {rating > 0 && <Star className="h-3 w-3 ml-1 fill-current" />}
                          </Button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">
                        Price Range: ₹{priceRange[0]} - ₹{priceRange[1]}/hr
                      </label>
                      <Slider
                        value={priceRange}
                        onValueChange={setPriceRange}
                        min={0}
                        max={2000}
                        step={100}
                        className="mt-4"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button variant="ghost" onClick={clearFilters} className="gap-2">
                        <X className="h-4 w-4" />
                        Clear All Filters
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>

          <section className="container mx-auto px-4 py-8">
            <div className="flex justify-between items-center mb-6">
              <p className="text-muted-foreground">
                {filteredProviders.length} service provider{filteredProviders.length !== 1 ? 's' : ''} found
              </p>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredProviders.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                  <Search className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="font-display text-xl font-semibold mb-2">No providers found</h3>
                <p className="text-muted-foreground mb-4">
                  {providers.length === 0 
                    ? 'No service providers have been approved yet. Check back later!'
                    : 'Try adjusting your filters or search terms'}
                </p>
                {providers.length > 0 && (
                  <Button variant="outline" onClick={clearFilters}>Clear Filters</Button>
                )}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProviders.map((provider) => (
                  <Card 
                    key={provider.id} 
                    className="group hover:shadow-lg hover:border-primary/20 transition-all duration-300 overflow-hidden"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4 mb-4">
                        <div className="w-16 h-16 rounded-xl gradient-hero flex items-center justify-center text-2xl flex-shrink-0 text-primary-foreground font-bold">
                          {provider.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-display font-semibold text-lg truncate">{provider.name}</h3>
                          <p className="text-sm text-muted-foreground truncate">{provider.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              {provider.category?.name || 'Service'}
                            </Badge>
                            {provider.badges?.includes('verified') && (
                              <CheckCircle className="h-4 w-4 text-success" />
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 mb-4 text-center">
                        <div className="bg-secondary/50 rounded-lg p-2">
                          <div className="flex items-center justify-center gap-1 text-sm font-semibold">
                            <Star className="h-4 w-4 text-accent fill-accent" />
                            {Number(provider.rating || 0).toFixed(1)}
                          </div>
                          <p className="text-xs text-muted-foreground">{provider.reviewCount || 0} reviews</p>
                        </div>
                        <div className="bg-secondary/50 rounded-lg p-2">
                          <div className="flex items-center justify-center gap-1 text-sm font-semibold">
                            <IndianRupee className="h-4 w-4" />
                            {provider.hourlyRate}
                          </div>
                          <p className="text-xs text-muted-foreground">per hour</p>
                        </div>
                        <div className="bg-secondary/50 rounded-lg p-2">
                          <div className="flex items-center justify-center gap-1 text-sm font-semibold">
                            <Clock className="h-4 w-4" />
                            Quick
                          </div>
                          <p className="text-xs text-muted-foreground">response</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                        <MapPin className="h-4 w-4" />
                        <span className="truncate">{provider.location || 'Location not set'}</span>
                      </div>

                      <Button 
                        variant="hero" 
                        className="w-full"
                        onClick={() => handleBookNow(provider.id)}
                      >
                        Book Now
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </section>
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default Services;
