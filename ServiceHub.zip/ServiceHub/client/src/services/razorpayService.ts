import { supabase } from '@/integrations/supabase/client';

declare global {
  interface Window {
    Razorpay: any;
  }
}

export interface RazorpayResponse {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

export interface PaymentOptions {
  bookingId: string;
  amount: number;
  prefill?: {
    name?: string;
    email?: string;
    contact?: string;
  };
  onSuccess: (response: RazorpayResponse) => void;
  onError: (error: any) => void;
}

// Load Razorpay script dynamically
const loadRazorpayScript = (): Promise<boolean> => {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
};

export const initiatePayment = async (options: PaymentOptions) => {
  const { bookingId, amount, prefill, onSuccess, onError } = options;

  try {
    // Load Razorpay script
    const scriptLoaded = await loadRazorpayScript();
    if (!scriptLoaded) {
      throw new Error('Failed to load Razorpay SDK');
    }

    // Create order via edge function
    const { data, error } = await supabase.functions.invoke('create-razorpay-order', {
      body: { amount, bookingId },
    });

    if (error) {
      console.error('Error creating order:', error);
      throw new Error(error.message || 'Failed to create payment order');
    }

    if (!data || !data.orderId) {
      throw new Error('Invalid order response');
    }

    const { orderId, keyId } = data;

    // Configure Razorpay checkout options
    const razorpayOptions = {
      key: keyId,
      amount: Math.round(amount * 100), // Amount in paise
      currency: 'INR',
      name: 'Service Booking',
      description: `Payment for Booking #${bookingId.slice(0, 8)}`,
      order_id: orderId,
      prefill: {
        name: prefill?.name || '',
        email: prefill?.email || '',
        contact: prefill?.contact || '',
      },
      theme: {
        color: '#6366f1',
      },
      handler: function (response: RazorpayResponse) {
        console.log('Payment successful:', response);
        onSuccess(response);
      },
      modal: {
        ondismiss: function () {
          console.log('Payment modal closed');
          onError({ message: 'Payment cancelled by user' });
        },
      },
    };

    // Open Razorpay checkout
    const razorpay = new window.Razorpay(razorpayOptions);
    razorpay.on('payment.failed', function (response: any) {
      console.error('Payment failed:', response.error);
      onError({
        code: response.error.code,
        message: response.error.description,
        reason: response.error.reason,
      });
    });

    razorpay.open();
  } catch (error: any) {
    console.error('Payment initiation error:', error);
    onError(error);
  }
};
