package com.serviceconnect.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class RegisterRequest {
    @NotBlank
    @Email
    private String email;
    
    @NotBlank
    private String password;
    
    @NotBlank
    private String name;
    
    private String phone;
    
    @NotBlank
    private String role;
    
    private String category;
    private String description;
    private Double hourlyRate;
    private String location;
    private Double latitude;
    private Double longitude;
    private String workHours;
}
