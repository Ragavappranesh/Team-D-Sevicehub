export type UserRole = 'user' | 'provider' | 'admin';

export type BookingStatus = 'requested' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';

export type PaymentStatus = 'pending' | 'completed' | 'failed' | 'refunded';

export type ProviderStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: UserRole;
  avatar?: string;
  createdAt: Date;
}

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  image?: string;
}

export interface ServiceProvider {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  category: string;
  description: string;
  hourlyRate: number;
  rating: number;
  reviewCount: number;
  avatar?: string;
  status: ProviderStatus;
  location: string;
  workHours: string;
  badges: string[];
  createdAt: Date;
}

export interface Booking {
  id: string;
  userId: string;
  providerId: string;
  providerName: string;
  serviceName: string;
  status: BookingStatus;
  scheduledDate: Date;
  startTime?: Date;
  endTime?: Date;
  totalHours?: number;
  hourlyRate: number;
  totalAmount?: number;
  paymentStatus: PaymentStatus;
  location: string;
  notes?: string;
  createdAt: Date;
}

export interface Review {
  id: string;
  bookingId: string;
  userId: string;
  providerId: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  bookingId: string;
  senderId: string;
  senderRole: UserRole;
  content: string;
  type: 'text' | 'image' | 'location' | 'payment';
  timestamp: Date;
}
