import { ServiceCategory } from '@/types';

export const serviceCategories: ServiceCategory[] = [
  {
    id: 'plumbing',
    name: 'Plumbing',
    description: 'Pipe repairs, leak fixing, installations',
    icon: '🔧',
  },
  {
    id: 'electrical',
    name: 'Electrical',
    description: 'Wiring, repairs, installations',
    icon: '⚡',
  },
  {
    id: 'cleaning',
    name: 'Cleaning',
    description: 'Home & office deep cleaning',
    icon: '🧹',
  },
  {
    id: 'appliance',
    name: 'Appliance Repair',
    description: 'AC, refrigerator, washing machine',
    icon: '🔌',
  },
  {
    id: 'beauty',
    name: 'Beauty & Spa',
    description: 'Salon services at your doorstep',
    icon: '💅',
  },
  {
    id: 'carpentry',
    name: 'Carpentry',
    description: 'Furniture repair & assembly',
    icon: '🪚',
  },
  {
    id: 'painting',
    name: 'Painting',
    description: 'Interior & exterior painting',
    icon: '🎨',
  },
  {
    id: 'pest-control',
    name: 'Pest Control',
    description: 'Safe & effective pest removal',
    icon: '🐜',
  },
];
