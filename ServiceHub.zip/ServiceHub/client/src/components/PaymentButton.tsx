import React, { useState } from 'react';
import { CreditCard, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { initiatePayment, RazorpayResponse } from '@/services/razorpayService';
import { toast } from 'sonner';

interface PaymentButtonProps {
  bookingId: string;
  amount: number;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
  onSuccess?: (response: RazorpayResponse) => void;
  onError?: (error: any) => void;
  disabled?: boolean;
}

export const PaymentButton: React.FC<PaymentButtonProps> = ({
  bookingId,
  amount,
  userName,
  userEmail,
  userPhone,
  onSuccess,
  onError,
  disabled = false,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePayment = async () => {
    setIsProcessing(true);

    await initiatePayment({
      bookingId,
      amount,
      prefill: {
        name: userName,
        email: userEmail,
        contact: userPhone,
      },
      onSuccess: (response) => {
        setIsProcessing(false);
        toast.success('Payment successful!');
        onSuccess?.(response);
      },
      onError: (error) => {
        setIsProcessing(false);
        toast.error(error.message || 'Payment failed');
        onError?.(error);
      },
    });
  };

  return (
    <Button
      onClick={handlePayment}
      disabled={disabled || isProcessing}
      className="w-full"
      size="lg"
    >
      {isProcessing ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Processing...
        </>
      ) : (
        <>
          <CreditCard className="mr-2 h-4 w-4" />
          Pay ₹{amount.toLocaleString()}
        </>
      )}
    </Button>
  );
};
