import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Navigation, Loader2, ExternalLink } from 'lucide-react';

interface LocationPickerProps {
  onLocationSelect: (location: { address: string; lat: number; lng: number }) => void;
  currentLocation?: { address: string; lat?: number; lng?: number };
  className?: string;
  showViewButton?: boolean;
}

const LocationPicker: React.FC<LocationPickerProps> = ({
  onLocationSelect,
  currentLocation,
  className = '',
  showViewButton = false,
}) => {
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [address, setAddress] = useState(currentLocation?.address || '');
  const { toast } = useToast();

  const getCurrentLocation = () => {
    setIsGettingLocation(true);
    
    if (!navigator.geolocation) {
      toast({
        title: 'Not supported',
        description: 'Geolocation is not supported by your browser.',
        variant: 'destructive',
      });
      setIsGettingLocation(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        try {
          // Reverse geocoding
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();
          const addr = data.address;
          const locationText = [
            addr.road || addr.suburb || addr.neighbourhood,
            addr.city || addr.town || addr.village || addr.state_district,
            addr.state,
          ].filter(Boolean).join(', ');

          setAddress(locationText);
          onLocationSelect({
            address: locationText,
            lat: latitude,
            lng: longitude,
          });

          toast({
            title: 'Location detected',
            description: 'Your current location has been set.',
          });
        } catch (error) {
          const locationText = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
          setAddress(locationText);
          onLocationSelect({
            address: locationText,
            lat: latitude,
            lng: longitude,
          });
        }
        
        setIsGettingLocation(false);
      },
      (error) => {
        let message = 'Unable to get your location.';
        if (error.code === error.PERMISSION_DENIED) {
          message = 'Location permission denied. Please enable it in your browser settings.';
        }
        toast({
          title: 'Location error',
          description: message,
          variant: 'destructive',
        });
        setIsGettingLocation(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const openInMaps = () => {
    if (currentLocation?.lat && currentLocation?.lng) {
      window.open(
        `https://www.google.com/maps?q=${currentLocation.lat},${currentLocation.lng}`,
        '_blank'
      );
    } else if (address) {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`,
        '_blank'
      );
    }
  };

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="relative">
        <Input
          value={address}
          onChange={(e) => {
            setAddress(e.target.value);
            onLocationSelect({ address: e.target.value, lat: 0, lng: 0 });
          }}
          placeholder="Enter location or use GPS"
          className="pr-20"
        />
        <div className="absolute right-0 top-0 h-full flex items-center gap-1 pr-1">
          {showViewButton && address && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={openInMaps}
              title="View in Maps"
            >
              <ExternalLink className="h-4 w-4 text-muted-foreground" />
            </Button>
          )}
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={getCurrentLocation}
            disabled={isGettingLocation}
            title="Use current location"
          >
            {isGettingLocation ? (
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            ) : (
              <Navigation className="h-4 w-4 text-muted-foreground" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LocationPicker;
