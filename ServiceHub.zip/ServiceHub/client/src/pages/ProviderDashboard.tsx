import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Navbar from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Calendar, Clock, MapPin, IndianRupee, Star, CheckCircle, XCircle, Play, Square, Loader2 } from 'lucide-react';

interface Provider {
  id: string;
  name: string;
  description?: string;
  hourly_rate: number;
  rating: number;
  review_count: number;
  category?: { name: string };
}

interface Booking {
  id: string;
  user_id: string;
  provider_id: string;
  status: string;
  scheduled_date: string;
  start_time?: string;
  end_time?: string;
  total_hours?: number;
  hourly_rate: number;
  total_amount?: number;
  payment_status: string;
  location: string;
  notes?: string;
  provider?: { name: string };
  profile?: { name: string };
}

const ProviderDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('pending');
  const [isLoading, setIsLoading] = useState(true);
  const [provider, setProvider] = useState<Provider | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    if (!user || user.role !== 'provider') {
      navigate('/auth');
      return;
    }
    fetchData();
  }, [user, navigate]);

  const fetchData = async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      // Get provider profile
      const { data: providerData } = await supabase
        .from('service_providers')
        .select('*, category:service_categories(name)')
        .eq('user_id', user.id)
        .maybeSingle();

      if (providerData) {
        setProvider(providerData);

        // Get bookings for this provider
        const { data: bookingsData } = await supabase
          .from('bookings')
          .select('*')
          .eq('provider_id', providerData.id)
          .order('created_at', { ascending: false });

        if (bookingsData) setBookings(bookingsData);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const pendingBookings = bookings.filter(b => b.status === 'requested');
  const activeBookings = bookings.filter(b => ['accepted', 'in_progress'].includes(b.status));
  const completedBookings = bookings.filter(b => b.status === 'completed');

  const totalEarnings = completedBookings
    .filter(b => b.payment_status === 'completed')
    .reduce((sum, b) => sum + (b.total_amount || 0), 0);

  const handleAccept = async (bookingId: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status: 'accepted' })
      .eq('id', bookingId);

    if (error) {
      toast({ title: 'Error', description: 'Failed to accept booking.', variant: 'destructive' });
    } else {
      toast({ title: 'Booking Accepted', description: 'You can now chat with the customer.' });
      fetchData();
    }
  };

  const handleReject = async (bookingId: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .eq('id', bookingId);

    if (error) {
      toast({ title: 'Error', description: 'Failed to reject booking.', variant: 'destructive' });
    } else {
      toast({ title: 'Booking Rejected', description: 'The booking has been cancelled.', variant: 'destructive' });
      fetchData();
    }
  };

  const handleStartService = async (bookingId: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status: 'in_progress', start_time: new Date().toISOString() })
      .eq('id', bookingId);

    if (error) {
      toast({ title: 'Error', description: 'Failed to start service.', variant: 'destructive' });
    } else {
      toast({ title: 'Service Started', description: 'Timer has started. Mark as complete when finished.' });
      fetchData();
    }
  };

  const handleEndService = async (bookingId: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking || !booking.start_time) return;

    const endTime = new Date();
    const startTime = new Date(booking.start_time);
    const totalHours = Math.max(1, Math.ceil((endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60)));
    const totalAmount = totalHours * booking.hourly_rate;

    const { error } = await supabase
      .from('bookings')
      .update({ 
        status: 'completed', 
        end_time: endTime.toISOString(),
        total_hours: totalHours,
        total_amount: totalAmount,
      })
      .eq('id', bookingId);

    if (error) {
      toast({ title: 'Error', description: 'Failed to complete service.', variant: 'destructive' });
    } else {
      toast({ title: 'Service Completed', description: 'The customer will be notified to make payment.' });
      fetchData();
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'requested': return 'accent';
      case 'accepted': return 'default';
      case 'in_progress': return 'coral';
      case 'completed': return 'success';
      default: return 'secondary';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Provider Dashboard - ServiceHub</title>
        <meta name="description" content="Manage your service bookings and track earnings on ServiceHub." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold mb-2">Provider Dashboard</h1>
            <p className="text-muted-foreground">Manage your bookings and track your performance</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-2xl font-display font-bold">{pendingBookings.length}</p>
                    <p className="text-xs text-muted-foreground">Pending Requests</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-coral/10 flex items-center justify-center">
                    <Play className="h-5 w-5 text-coral" />
                  </div>
                  <div>
                    <p className="text-2xl font-display font-bold">{activeBookings.length}</p>
                    <p className="text-xs text-muted-foreground">Active Jobs</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-2xl font-display font-bold">{completedBookings.length}</p>
                    <p className="text-xs text-muted-foreground">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <IndianRupee className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-display font-bold">₹{totalEarnings}</p>
                    <p className="text-xs text-muted-foreground">Total Earnings</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {provider && (
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl gradient-hero flex items-center justify-center text-2xl text-primary-foreground font-bold">
                    {provider.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-display font-semibold text-lg">{provider.name}</h3>
                    <p className="text-muted-foreground">{provider.description}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <Badge variant="secondary">{provider.category?.name || 'Service'}</Badge>
                      <span className="text-sm flex items-center gap-1">
                        <Star className="h-4 w-4 text-accent fill-accent" />
                        {Number(provider.rating).toFixed(1)} ({provider.review_count} reviews)
                      </span>
                      <span className="text-sm">₹{provider.hourly_rate}/hr</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Bookings</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-4">
                  <TabsTrigger value="pending">Pending ({pendingBookings.length})</TabsTrigger>
                  <TabsTrigger value="active">Active ({activeBookings.length})</TabsTrigger>
                  <TabsTrigger value="completed">Completed ({completedBookings.length})</TabsTrigger>
                </TabsList>

                <TabsContent value="pending">
                  {pendingBookings.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No pending booking requests</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {pendingBookings.map((booking) => (
                        <div key={booking.id} className="p-4 rounded-xl bg-secondary/30 border">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="font-semibold">Service Booking</h4>
                              <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  {new Date(booking.scheduled_date).toLocaleDateString()}
                                </span>
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {booking.location}
                                </span>
                              </div>
                            </div>
                            <Badge variant="accent">New Request</Badge>
                          </div>
                          {booking.notes && (
                            <p className="text-sm text-muted-foreground mb-3 bg-muted p-2 rounded">"{booking.notes}"</p>
                          )}
                          <div className="flex gap-2">
                            <Button variant="success" size="sm" onClick={() => handleAccept(booking.id)} className="gap-1">
                              <CheckCircle className="h-4 w-4" />
                              Accept
                            </Button>
                            <Button variant="destructive" size="sm" onClick={() => handleReject(booking.id)} className="gap-1">
                              <XCircle className="h-4 w-4" />
                              Reject
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="active">
                  {activeBookings.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No active jobs</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {activeBookings.map((booking) => (
                        <div key={booking.id} className="p-4 rounded-xl bg-secondary/30 border">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="font-semibold">Service Booking</h4>
                              <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {booking.location}
                                </span>
                              </div>
                            </div>
                            <Badge variant={getStatusColor(booking.status)}>
                              {booking.status === 'in_progress' ? 'In Progress' : 'Accepted'}
                            </Badge>
                          </div>
                          <div className="flex gap-2">
                            {booking.status === 'accepted' && (
                              <Button variant="coral" size="sm" onClick={() => handleStartService(booking.id)} className="gap-1">
                                <Play className="h-4 w-4" />
                                Start Service
                              </Button>
                            )}
                            {booking.status === 'in_progress' && (
                              <Button variant="success" size="sm" onClick={() => handleEndService(booking.id)} className="gap-1">
                                <Square className="h-4 w-4" />
                                Mark Complete
                              </Button>
                            )}
                            <Button variant="outline" size="sm" onClick={() => navigate(`/booking/${booking.id}`)}>
                              View Details
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="completed">
                  {completedBookings.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No completed jobs yet</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {completedBookings.map((booking) => (
                        <div key={booking.id} className="p-4 rounded-xl bg-secondary/30">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold">Service Completed</h4>
                              <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                                <span>{booking.total_hours} hours</span>
                                <span className="font-semibold text-foreground">₹{booking.total_amount}</span>
                              </div>
                            </div>
                            <Badge variant={booking.payment_status === 'completed' ? 'success' : 'accent'}>
                              {booking.payment_status === 'completed' ? 'Paid' : 'Payment Pending'}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default ProviderDashboard;
