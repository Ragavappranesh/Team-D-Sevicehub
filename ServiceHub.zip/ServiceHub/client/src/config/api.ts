// Configure your Java Spring Boot backend URL here
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api';

// Razorpay configuration
export const RAZORPAY_KEY_ID = import.meta.env.VITE_RAZORPAY_KEY_ID || '';

export const API_ENDPOINTS = {
  // Auth endpoints
  AUTH: {
    LOGIN: `${API_BASE_URL}/auth/login`,
    REGISTER: `${API_BASE_URL}/auth/register`,
    LOGOUT: `${API_BASE_URL}/auth/logout`,
    ME: `${API_BASE_URL}/auth/me`,
  },
  
  // User endpoints
  USERS: {
    BASE: `${API_BASE_URL}/users`,
    BY_ID: (id: string) => `${API_BASE_URL}/users/${id}`,
    PROFILE: `${API_BASE_URL}/users/profile`,
  },
  
  // Service Provider endpoints
  PROVIDERS: {
    BASE: `${API_BASE_URL}/providers`,
    BY_ID: (id: string) => `${API_BASE_URL}/providers/${id}`,
    APPROVE: (id: string) => `${API_BASE_URL}/providers/${id}/approve`,
    REJECT: (id: string) => `${API_BASE_URL}/providers/${id}/reject`,
    PORTFOLIO: (id: string) => `${API_BASE_URL}/providers/${id}/portfolio`,
  },
  
  // Category endpoints
  CATEGORIES: {
    BASE: `${API_BASE_URL}/categories`,
    BY_ID: (id: string) => `${API_BASE_URL}/categories/${id}`,
  },
  
  // Booking endpoints
  BOOKINGS: {
    BASE: `${API_BASE_URL}/bookings`,
    BY_ID: (id: string) => `${API_BASE_URL}/bookings/${id}`,
    USER_BOOKINGS: `${API_BASE_URL}/bookings/user`,
    PROVIDER_BOOKINGS: `${API_BASE_URL}/bookings/provider`,
    ACCEPT: (id: string) => `${API_BASE_URL}/bookings/${id}/accept`,
    REJECT: (id: string) => `${API_BASE_URL}/bookings/${id}/reject`,
    START: (id: string) => `${API_BASE_URL}/bookings/${id}/start`,
    END: (id: string) => `${API_BASE_URL}/bookings/${id}/end`,
  },
  
  // Chat endpoints
  CHAT: {
    MESSAGES: (bookingId: string) => `${API_BASE_URL}/chat/${bookingId}/messages`,
    SEND: (bookingId: string) => `${API_BASE_URL}/chat/${bookingId}/send`,
  },
  
  // Review endpoints
  REVIEWS: {
    BASE: `${API_BASE_URL}/reviews`,
    BY_PROVIDER: (providerId: string) => `${API_BASE_URL}/reviews/provider/${providerId}`,
    BY_BOOKING: (bookingId: string) => `${API_BASE_URL}/reviews/booking/${bookingId}`,
  },
  
  // Payment endpoints
  PAYMENTS: {
    CREATE_ORDER: `${API_BASE_URL}/payments/create-order`,
    VERIFY: `${API_BASE_URL}/payments/verify`,
  },
  
  // Notification endpoints
  NOTIFICATIONS: {
    BASE: `${API_BASE_URL}/notifications`,
    MARK_READ: (id: string) => `${API_BASE_URL}/notifications/${id}/read`,
    MARK_ALL_READ: `${API_BASE_URL}/notifications/read-all`,
  },
  
  // File upload endpoints
  UPLOAD: {
    AVATAR: `${API_BASE_URL}/upload/avatar`,
    PORTFOLIO: `${API_BASE_URL}/upload/portfolio`,
    CHAT: `${API_BASE_URL}/upload/chat`,
  },
  
  // Admin endpoints
  ADMIN: {
    DASHBOARD: `${API_BASE_URL}/admin/dashboard`,
    USERS: `${API_BASE_URL}/admin/users`,
    PROVIDERS: `${API_BASE_URL}/admin/providers`,
    BOOKINGS: `${API_BASE_URL}/admin/bookings`,
  },
};
