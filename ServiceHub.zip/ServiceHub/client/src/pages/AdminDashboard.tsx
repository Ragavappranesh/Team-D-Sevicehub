import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Navbar from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Users, Briefcase, Calendar, IndianRupee, 
  CheckCircle, XCircle, Clock, Search, 
  TrendingUp, Star, MapPin, Mail, Phone,
  Loader2
} from 'lucide-react';
import { format } from 'date-fns';

interface User {
  id: string;
  name: string;
  email: string;
}

interface ServiceProvider {
  id: string;
  name: string;
  email: string;
  phone: string;
  description: string | null;
  hourlyRate: number;
  rating: number | null;
  location: string | null;
  status: string;
  categoryId: string | null;
  category?: { name: string } | null;
}

interface Booking {
  id: string;
  status: string;
  paymentStatus: string;
  totalAmount: number | null;
  scheduledDate: string;
  user?: { name: string; email: string };
  provider?: { name: string };
}

interface ServiceCategory {
  id: string;
  name: string;
}

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  
  const [users, setUsers] = useState<User[]>([]);
  const [providers, setProviders] = useState<ServiceProvider[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [categories, setCategories] = useState<ServiceCategory[]>([]);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/auth');
      return;
    }
    fetchData();
  }, [user, navigate]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch profiles (users)
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, name, email, user_id');
      
      if (profilesError) throw profilesError;

      // Fetch all providers (including pending)
      const { data: providersData, error: providersError } = await supabase
        .from('service_providers')
        .select(`
          id, name, email, phone, description, 
          hourly_rate, rating, location, status, category_id,
          service_categories(name)
        `);
      
      if (providersError) throw providersError;

      // Fetch bookings with provider data only (no direct FK to profiles)
      const { data: bookingsData, error: bookingsError } = await supabase
        .from('bookings')
        .select(`
          id, status, payment_status, total_amount, scheduled_date, user_id,
          service_providers(name)
        `)
        .order('created_at', { ascending: false });
      
      if (bookingsError) throw bookingsError;

      // Fetch categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('service_categories')
        .select('id, name');
      
      if (categoriesError) throw categoriesError;

      // Create a map of user_id to profile for quick lookup
      const profileMap = new Map((profilesData || []).map(p => [p.user_id, p]));

      // Transform data
      setUsers(profilesData || []);
      setProviders((providersData || []).map((p: any) => ({
        id: p.id,
        name: p.name,
        email: p.email,
        phone: p.phone,
        description: p.description,
        hourlyRate: p.hourly_rate,
        rating: p.rating,
        location: p.location,
        status: p.status,
        categoryId: p.category_id,
        category: p.service_categories,
      })));
      setBookings((bookingsData || []).map((b: any) => {
        const userProfile = profileMap.get(b.user_id);
        return {
          id: b.id,
          status: b.status,
          paymentStatus: b.payment_status,
          totalAmount: b.total_amount,
          scheduledDate: b.scheduled_date,
          user: userProfile ? { name: userProfile.name, email: userProfile.email } : null,
          provider: b.service_providers,
        };
      }));
      setCategories(categoriesData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load dashboard data.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const pendingProviders = providers.filter(p => p.status === 'pending');
  const approvedProviders = providers.filter(p => p.status === 'approved');
  
  const totalRevenue = bookings
    .filter(b => b.paymentStatus === 'completed')
    .reduce((sum, b) => sum + (b.totalAmount || 0), 0);

  const handleApprove = async (providerId: string) => {
    try {
      const { error } = await supabase
        .from('service_providers')
        .update({ status: 'approved' })
        .eq('id', providerId);

      if (error) throw error;

      toast({
        title: 'Provider Approved',
        description: 'The provider can now start accepting bookings.',
      });
      fetchData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to approve provider.',
        variant: 'destructive',
      });
    }
  };

  const handleReject = async (providerId: string) => {
    try {
      const { error } = await supabase
        .from('service_providers')
        .update({ status: 'rejected' })
        .eq('id', providerId);

      if (error) throw error;

      toast({
        title: 'Provider Rejected',
        description: 'The provider application has been rejected.',
        variant: 'destructive',
      });
      fetchData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to reject provider.',
        variant: 'destructive',
      });
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredProviders = providers.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Admin Dashboard - ServiceHub</title>
        <meta name="description" content="Admin control panel for ServiceHub platform management." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage platform users, providers, and bookings</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Total Users', value: users.length, icon: Users, color: 'bg-primary/10 text-primary' },
              { label: 'Providers', value: approvedProviders.length, icon: Briefcase, color: 'bg-success/10 text-success' },
              { label: 'Pending Approvals', value: pendingProviders.length, icon: Clock, color: 'bg-accent/10 text-accent' },
              { label: 'Total Revenue', value: `₹${totalRevenue}`, icon: IndianRupee, color: 'bg-coral/10 text-coral' },
            ].map((stat, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl ${stat.color} flex items-center justify-center`}>
                      <stat.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="text-2xl font-display font-bold">{stat.value}</p>
                      <p className="text-xs text-muted-foreground">{stat.label}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader className="border-b">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <CardTitle>Management Panel</CardTitle>
                <div className="relative w-full md:w-80">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users or providers..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
                  <TabsTrigger value="overview" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent">
                    Overview
                  </TabsTrigger>
                  <TabsTrigger value="pending" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent">
                    Pending Approvals
                    {pendingProviders.length > 0 && (
                      <Badge variant="destructive" className="ml-2">{pendingProviders.length}</Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="users" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent">
                    Users
                  </TabsTrigger>
                  <TabsTrigger value="providers" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent">
                    Providers
                  </TabsTrigger>
                  <TabsTrigger value="bookings" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent">
                    Bookings
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="p-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <TrendingUp className="h-4 w-4" />
                        Platform Statistics
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between p-3 bg-secondary/30 rounded-lg">
                          <span className="text-muted-foreground">Total Bookings</span>
                          <span className="font-semibold">{bookings.length}</span>
                        </div>
                        <div className="flex justify-between p-3 bg-secondary/30 rounded-lg">
                          <span className="text-muted-foreground">Completed Services</span>
                          <span className="font-semibold">{bookings.filter(b => b.status === 'completed').length}</span>
                        </div>
                        <div className="flex justify-between p-3 bg-secondary/30 rounded-lg">
                          <span className="text-muted-foreground">Active Providers</span>
                          <span className="font-semibold">{approvedProviders.length}</span>
                        </div>
                        <div className="flex justify-between p-3 bg-secondary/30 rounded-lg">
                          <span className="text-muted-foreground">Service Categories</span>
                          <span className="font-semibold">{categories.length}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <Star className="h-4 w-4" />
                        Providers by Category
                      </h3>
                      <div className="space-y-2">
                        {categories.map((cat) => {
                          const count = approvedProviders.filter(p => p.categoryId === cat.id).length;
                          return (
                            <div key={cat.id} className="flex items-center gap-3 p-2 bg-secondary/30 rounded-lg">
                              <span className="flex-1">{cat.name}</span>
                              <Badge variant="secondary">{count}</Badge>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="pending" className="p-6">
                  {pendingProviders.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="h-8 w-8 text-success" />
                      </div>
                      <h3 className="font-semibold mb-2">All caught up!</h3>
                      <p className="text-muted-foreground">No pending provider applications</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {pendingProviders.map((provider) => (
                        <div key={provider.id} className="p-4 rounded-xl bg-secondary/30 border">
                          <div className="flex items-start gap-4">
                            <div className="w-14 h-14 rounded-xl gradient-hero flex items-center justify-center text-xl text-primary-foreground font-bold">
                              {provider.name.charAt(0)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-semibold text-lg">{provider.name}</h4>
                                <Badge variant="secondary">Pending Review</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">{provider.description}</p>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                                <div className="flex items-center gap-1 text-muted-foreground">
                                  <Mail className="h-4 w-4" />
                                  <span className="truncate">{provider.email}</span>
                                </div>
                                <div className="flex items-center gap-1 text-muted-foreground">
                                  <Phone className="h-4 w-4" />
                                  {provider.phone}
                                </div>
                                <div className="flex items-center gap-1 text-muted-foreground">
                                  <MapPin className="h-4 w-4" />
                                  {provider.location || 'N/A'}
                                </div>
                                <div className="flex items-center gap-1 text-muted-foreground">
                                  <IndianRupee className="h-4 w-4" />
                                  {provider.hourlyRate}/hr
                                </div>
                              </div>
                              <Badge variant="secondary" className="mt-2">
                                {provider.category?.name || 'Uncategorized'}
                              </Badge>
                            </div>
                            <div className="flex flex-col gap-2">
                              <Button 
                                variant="default" 
                                size="sm"
                                onClick={() => handleApprove(provider.id)}
                                className="gap-1"
                              >
                                <CheckCircle className="h-4 w-4" />
                                Approve
                              </Button>
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => handleReject(provider.id)}
                                className="gap-1"
                              >
                                <XCircle className="h-4 w-4" />
                                Reject
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="users" className="p-6">
                  {filteredUsers.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No users registered yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredUsers.map((profile) => (
                        <div key={profile.id} className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <Users className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{profile.name}</p>
                            <p className="text-sm text-muted-foreground">{profile.email}</p>
                          </div>
                          <Badge variant="secondary">User</Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="providers" className="p-6">
                  {filteredProviders.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No providers found</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredProviders.map((provider) => (
                        <div key={provider.id} className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <Briefcase className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{provider.name}</p>
                            <p className="text-sm text-muted-foreground">{provider.email}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={provider.status === 'approved' ? 'default' : 'secondary'}>
                              {provider.status}
                            </Badge>
                            <div className="flex items-center gap-1 text-sm">
                              <Star className="h-4 w-4 text-accent fill-accent" />
                              {Number(provider.rating || 0).toFixed(1)}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="bookings" className="p-6">
                  {bookings.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No bookings yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {bookings.map((booking) => (
                        <div key={booking.id} className="flex items-center gap-4 p-3 rounded-lg bg-secondary/30">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <Calendar className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{booking.user?.name || 'Unknown User'}</p>
                            <p className="text-sm text-muted-foreground">
                              with {booking.provider?.name || 'Unknown Provider'} • {format(new Date(booking.scheduledDate), 'MMM d, yyyy')}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={
                              booking.status === 'completed' ? 'default' :
                              booking.status === 'cancelled' ? 'destructive' : 'secondary'
                            }>
                              {booking.status}
                            </Badge>
                            {booking.totalAmount && (
                              <span className="text-sm font-medium">₹{booking.totalAmount}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default AdminDashboard;
