import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Loader2 } from 'lucide-react';

interface LocationShareButtonProps {
  onShare: (location: { lat: number; lng: number; address: string }) => void;
  disabled?: boolean;
  className?: string;
}

const LocationShareButton: React.FC<LocationShareButtonProps> = ({
  onShare,
  disabled = false,
  className = '',
}) => {
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const { toast } = useToast();

  const shareLocation = () => {
    setIsGettingLocation(true);

    if (!navigator.geolocation) {
      toast({
        title: 'Not supported',
        description: 'Geolocation is not supported by your browser.',
        variant: 'destructive',
      });
      setIsGettingLocation(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;

        try {
          // Reverse geocoding
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();
          const addr = data.address;
          const locationText = [
            addr.road || addr.suburb || addr.neighbourhood,
            addr.city || addr.town || addr.village || addr.state_district,
          ].filter(Boolean).join(', ') || 'Current Location';

          onShare({
            lat: latitude,
            lng: longitude,
            address: locationText,
          });

          toast({
            title: 'Location shared',
            description: 'Your location has been sent.',
          });
        } catch (error) {
          onShare({
            lat: latitude,
            lng: longitude,
            address: 'Current Location',
          });
        }

        setIsGettingLocation(false);
      },
      (error) => {
        let message = 'Unable to get your location.';
        if (error.code === error.PERMISSION_DENIED) {
          message = 'Location permission denied.';
        }
        toast({
          title: 'Location error',
          description: message,
          variant: 'destructive',
        });
        setIsGettingLocation(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      onClick={shareLocation}
      disabled={disabled || isGettingLocation}
      className={className}
      title="Share location"
    >
      {isGettingLocation ? (
        <Loader2 className="h-5 w-5 animate-spin" />
      ) : (
        <MapPin className="h-5 w-5" />
      )}
    </Button>
  );
};

export default LocationShareButton;
